/*var RegionesYcomunas = {

  "regiones": [
  {
      "NombreRegion": "Regi&oacute;n Metropolitana de Santiago",
      "CodigoRegion": "Metropolitana",
      "comunas": ["Cerrillos", "Cerro Navia", "Conchal&iacute;", "El Bosque", "Estaci&oacute;n Central", "Huechuraba", "Independencia", "La Cisterna", "La Florida", "La Granja", "La Pintana", "La Reina", "Las Condes", "Lo Barnechea", "Lo Espejo", "Lo Prado", "Macul", "Maip&uacute;", "&Ntilde;u&ntilde;oa", "Pedro Aguirre Cerda", "Pe&ntilde;alol&eacute;n", "Providencia", "Pudahuel", "Quilicura", "Quinta Normal", "Recoleta", "Renca", "San Joaqu&iacute;n", "San Miguel", "San Ram&oacute;n", "Vitacura", "Puente Alto", "Pirque", "San Jos&eacute; de Maipo", "Colina", "Lampa", "TilVl", "San Bernardo", "Buin", "Calera de Tango", "Paine", "Melipilla", "Alhu&eacute;", "Curacav&iacute;", "Mar&iacute;a Pinto", "San Pedro", "Talagante", "El Monte", "Isla de Maipo", "Padre Hurtado", "Pe&ntilde;aflor"]
  },
  {
      "NombreRegion": "Arica y Parinacota",
      "CodigoRegion": "Arica y Parinacota",
      "comunas": ["Arica", "Camarones", "Putre", "General Lagos"]
  },
    {
      "NombreRegion": "Tarapac&aacute;",
      "CodigoRegion": "Tarapaca",
      "comunas": ["Iquique", "Alto Hospicio", "Pozo Almonte", "Cami&ntilde;a", "Colchane", "Huara", "Pica"]
  },
    {
      "NombreRegion": "Antofagasta",
      "CodigoRegion": "Antofagasta",
      "comunas": ["Antofagasta", "Mejillones", "Sierra Gorda", "Taltal", "Calama", "Ollag&uuml;e", "San Pedro de Atacama", "Tocopilla", "Mar&iacute;a Elena"]
  },
    {
      "NombreRegion": "Atacama",
      "CodigoRegion": "Atacama",
      "comunas": ["Copiap&oacute;", "Caldera", "Tierra Amarilla", "Cha&ntilde;aral", "Diego de Almagro", "Vallenar", "Alto del Carmen", "Freirina", "Huasco"]
  },
    {
      "NombreRegion": "Coquimbo",
      "CodigoRegion": "COQUIMBO",
      "comunas": ["La Serena", "Coquimbo", "Andacollo", "La Higuera", "Paiguano", "Vicu&ntilde;a", "Illapel", "Canela", "Los Vilos", "Salamanca", "Ovalle", "Combarbal&aacute;", "Monte Patria", "Punitaqui", "R&iacute;o Hurtado"]
  },
    {
      "NombreRegion": "Valpara&iacute;so",
      "CodigoRegion": "Valparaiso",
      "comunas": ["Valpara&iacute;so", "Casablanca", "Conc&oacute;n", "Juan Fern&aacute;ndez", "Puchuncav&iacute;", "Quintero", "Vi&ntilde;a del Mar", "Isla de Pascua", "Los Andes", "Calle Larga", "Rinconada", "San Esteban", "La Ligua", "Cabildo", "Papudo", "Petorca", "Zapallar", "Quillota", "Calera", "Hijuelas", "La Cruz", "Nogales", "San Antonio", "Algarrobo", "Cartagena", "El Quisco", "El Tabo", "Santo Domingo", "San Felipe", "Catemu", "Llaillay", "Panquehue", "Putaendo", "Santa Mar&iacute;a", "Quilpu&eacute;", "Limache", "Olmu&eacute;", "Villa Alemana"]
  },
    {
      "NombreRegion": "Regi&oacute;n del Libertador Gral. Bernardo O'Higgins",
      "CodigoRegion": "Libertador Gral. Bernardo Ohiggins",
      "comunas": ["Rancagua", "Codegua", "Coinco", "Coltauco", "Do&ntilde;ihue", "Graneros", "Las Cabras", "Machal&iacute;", "Malloa", "Mostazal", "Olivar", "Peumo", "Pichidegua", "Quinta de Tilcoco", "Rengo", "Requ&iacute;noa", "San Vicente", "Pichilemu", "La Estrella", "Litueche", "Marchihue", "Navidad", "Paredones", "San Fernando", "Ch&eacute;pica", "Chimbarongo", "Lolol", "Nancagua", "Palmilla", "Peralillo", "Placilla", "Pumanque", "Santa Cruz"]
  },
    {
      "NombreRegion": "Regi&oacute;n del Maule",
      "CodigoRegion": "Maule",
      "comunas": ["Talca", "ConsVtuci&oacute;n", "Curepto", "Empedrado", "Maule", "Pelarco", "Pencahue", "R&iacute;o Claro", "San Clemente", "San Rafael", "Cauquenes", "Chanco", "Pelluhue", "Curic&oacute;", "Huala&ntilde;&eacute;", "Licant&eacute;n", "Molina", "Rauco", "Romeral", "Sagrada Familia", "Teno", "Vichuqu&eacute;n", "Linares", "Colb&uacute;n", "Longav&iacute;", "Parral", "ReVro", "San Javier", "Villa Alegre", "Yerbas Buenas"]
  },
    {
      "NombreRegion": "Regi&oacute;n del Biob&iacute;o",
      "CodigoRegion": "BioBio",
      "comunas": ["Concepci&oacute;n", "Coronel", "Chiguayante", "Florida", "Hualqui", "Lota", "Penco", "San Pedro de la Paz", "Santa Juana", "Talcahuano", "Tom&eacute;", "Hualp&eacute;n", "Lebu", "Arauco", "Ca&ntilde;ete", "Contulmo", "Curanilahue", "Los &aacute;lamos", "Tir&uacute;a", "Los &aacute;ngeles", "Antuco", "Cabrero", "Laja", "Mulch&eacute;n", "Nacimiento", "Negrete", "Quilaco", "Quilleco", "San Rosendo", "Santa B&aacute;rbara", "Tucapel", "Yumbel", "Alto Biob&iacute;o", "Chill&aacute;n", "Bulnes", "Cobquecura", "Coelemu", "Coihueco", "Chill&aacute;n Viejo", "El Carmen", "Ninhue", "&Ntilde;iqu&eacute;n", "Pemuco", "Pinto", "Portezuelo", "Quill&oacute;n", "Quirihue", "R&aacute;nquil", "San Carlos", "San Fabi&aacute;n", "San Ignacio", "San Nicol&aacute;s", "Treguaco", "Yungay"]
  },
    {
      "NombreRegion": "Regi&oacute;n de la Araucan&iacute;a",
      "CodigoRegion": "Araucania",
      "comunas": ["Temuco", "Carahue", "Cunco", "Curarrehue", "Freire", "Galvarino", "Gorbea", "Lautaro", "Loncoche", "Melipeuco", "Nueva Imperial", "Padre las Casas", "Perquenco", "Pitrufqu&eacute;n", "Puc&oacute;n", "Saavedra", "Teodoro Schmidt", "Tolt&eacute;n", "Vilc&uacute;n", "Villarrica", "Cholchol", "Angol", "Collipulli", "Curacaut&iacute;n", "Ercilla", "Lonquimay", "Los Sauces", "Lumaco", "Pur&eacute;n", "Renaico", "Traigu&eacute;n", "Victoria", ]
  },
    {
      "NombreRegion": "Regi&oacute;n de Los R&iacute;os",
      "CodigoRegion": "Los Ríos",
      "comunas": ["Valdivia", "Corral", "Lanco", "Los Lagos", "M&aacute;fil", "Mariquina", "Paillaco", "Panguipulli", "La Uni&oacute;n", "Futrono", "Lago Ranco", "R&iacute;o Bueno"]
  },
    {
      "NombreRegion": "Regi&oacute;n de Los Lagos",
      "CodigoRegion": "Los Lagos",
      "comunas": ["Puerto Montt", "Calbuco", "Cocham&oacute;", "Fresia", "FruVllar", "Los Muermos", "Llanquihue", "Maull&iacute;n", "Puerto Varas", "Castro", "Ancud", "Chonchi", "Curaco de V&eacute;lez", "Dalcahue", "Puqueld&oacute;n", "Queil&eacute;n", "Quell&oacute;n", "Quemchi", "Quinchao", "Osorno", "Puerto Octay", "Purranque", "Puyehue", "R&iacute;o Negro", "San Juan de la Costa", "San Pablo", "Chait&eacute;n", "Futaleuf&uacute;", "Hualaihu&eacute;", "Palena"]
  },
    {
      "NombreRegion": "Regi&oacute;n Ais&eacute;n del Gral. Carlos Ib&aacute;&ntilde;ez del Campo",
      "CodigoRegion": "Aysén",
      "comunas": ["Coihaique", "Lago Verde", "Ais&eacute;n", "Cisnes", "Guaitecas", "Cochrane", "O'Higgins", "Tortel", "Chile Chico", "R&iacute;o Ib&aacute;&ntilde;ez"]
  },
    {
      "NombreRegion": "Regi&oacute;n de Magallanes y de la Ant&aacute;rtica Chilena",
      "CodigoRegion": "Magallanes",
      "comunas": ["Punta Arenas", "Laguna Blanca", "R&iacute;o Verde", "San Gregorio", "Cabo de Hornos (Ex Navarino)", "Ant&aacute;rVca", "Porvenir", "Primavera", "Timaukel", "Natales", "Torres del Paine"]
  }]
}
*/

/*$(document).ready(function () {

  var iRegion = 0;
  var htmlRegion = '<option value="sin-region">Selecciona regi&oacute;n</option>';
  var htmlComunas = '<option value="sin-region">Selecciona Comuna</option>';

  jQuery.each(RegionesYcomunas.regiones, function () {
    htmlRegion = htmlRegion + '<option value="' + RegionesYcomunas.regiones[iRegion].CodigoRegion + '">' + RegionesYcomunas.regiones[iRegion].NombreRegion + '</option>';
    iRegion++;
  });

  $('#regiones').html(htmlRegion);
  $('#comunas').html(htmlComunas);

  jQuery('#regiones').change(function () {
    var iRegiones = 0;
    var valorRegion = jQuery(this).val();
    var htmlComuna = '<option value="sin-comuna">Seleccione comuna</option><option value="all">Todas</option>';
    jQuery.each(RegionesYcomunas.regiones, function () {
      if (RegionesYcomunas.regiones[iRegiones].CodigoRegion == valorRegion) {
        var iComunas = 0;
        jQuery.each(RegionesYcomunas.regiones[iRegiones].comunas, function () {
          htmlComuna = htmlComuna + '<option value="' + RegionesYcomunas.regiones[iRegiones].comunas[iComunas] + '">' + RegionesYcomunas.regiones[iRegiones].comunas[iComunas] + '</option>';
          iComunas++;
        });
      }
      iRegiones++;

    });
    jQuery('#comunas').html(htmlComuna);

    $(".tabla-resultado").show();
    $("#search-field").val("");
    $(".tabla-resultado tbody tr").each(function(){
      var region = $(this).data("r");
      if(region != valorRegion && valorRegion != "all" ){
        $(this).hide();
      }else{
        $(this).show();
      }
      
    });
    
    $(".mobile-btn").click(function(){
    if($(window).width() <  768){
      if($(this).next(".mobile-desc").is(":visible")){
        $(this).next(".mobile-desc").hide();
      }else{
        $(this).next(".mobile-desc").show();
      }
    }
    $('.boton-modal-mapa').click(function() {
    var target = $(this).data('modal');
        $('#bgModal').removeClass('bgModalHide');
        $('#modal-mapa').removeClass('modalSimple');
        $('body').css('overflow','hidden');
        $("#iframe-modal-mapa").attr("src", target);
    });
      $('.cerrarModal').click(function() {
        $(".bgModal").addClass('bgModalHide');
        $(".contenedorModal").addClass('modalSimple');
        $('body').css('overflow','scroll');
         $("#iframe-modal-mapa").attr("src", "");
    });
    $('.contenedorModal').click(function() {
        $(".bgModal").addClass('bgModalHide');
        $(".contenedorModal").addClass('modalSimple');
        $('body').css('overflow','scroll');
        $("#iframe-modal-mapa").attr("src", "");
    });
    $('.contenedorModalSimple').click(function(event){
        event.stopPropagation();
    });
  });
    jQuery('#comunas').change(function(){
      var region = jQuery('#regiones').val();
      var comuna = $(this).val();
      $("#search-field").val("");
      $(".tabla-resultado tbody tr").each(function(){
        var comunaTR = $(this).data("c");
        var regionTR = $(this).data("r");
        if(comuna != comunaTR && comuna != "all"){
          $(this).hide();
        }else{
          if(region != regionTR){
            $(this).hide();
          }else{
            $(this).show();
          }
        }
      });
    });
    
    
  });
  $(".tabla-resultado").hide();
});
function buscarInput(){//BUSCAR TERMINO DESDE EL CAMPO DE BUSQUEDA
  $(".tabla-resultado").show();
  var valor = $("#search-field").val();
  valor = valor.toUpperCase();
  
  
  
  $(".tabla-resultado tbody tr").each(function(){
      if(valor != ""){
        var region = jQuery('#regiones').val();
        if(region == "sin-region"){ 
            var texto = $(this).data("t");
            var resultado = texto.indexOf(valor);
            if(resultado > 0){
              $(this).show();
            }else{
              $(this).hide();
            }
        }else{
          var regionTR = $('#regiones').val();
          var region = $(this).data("r");
          if(regionTR != region){
            $(this).hide();
          }else{
            var texto = $(this).data("t");
            if(texto.indexOf(valor) > 0){
              $(this).show();
            }else{
              $(this).hide();
            }
          }
          
        }//FIN IF REGION
      }else{
        var region = jQuery('#regiones').val();
        var comuna = $('#comunas').val();
        
        if(comuna != "sin-comuna"){
          var comunaTR = $(this).data("c");
          var regionTR = $(this).data("r");
          if(comuna != comunaTR && comuna != "all"){
            $(this).hide();
          }else{
            if(region != regionTR){
              $(this).hide();
            }else{
              $(this).show();
            }
          }
        }else if(region != "sin-region"){
          var regionAT = $(this).data("r");
          if(regionAT != region && region != "all" ){
            $(this).hide();
          }else{
            $(this).show();
          }
        }else{
          $(this).hide();
          
        }
      }
  });
}*/

$( document ).ready(function() {
    function acordeon(){
        $('.block .contenedorAcordeon').hide();
        $('.accordion h4').on('click',function(){
            var is_active = false;
            if($(this).find("span.icon-flecha-abajo").hasClass('flechaActiva')){
                is_active = true;
            }
            $('.accordion h4 span.icon-flecha-abajo').removeClass("flechaActiva");
            if(!is_active){
                $(this).find("span.icon-flecha-abajo").addClass("flechaActiva");
            }
            if($(this).next().find('.contenedorAcordeon').is(':visible')){
                $(this).next().find('.contenedorAcordeon').slideUp();
            }
            if($(this).next().find('.contenedorAcordeon').is(':hidden')){
                $('.accordion h4').next().find('.contenedorAcordeon').slideUp();
                $(this).next().find('.contenedorAcordeon').slideDown();
            }
        });
    }

    
    acordeon();

});