/*
 Creado por Claudio Figueroa Ariasn

 ¿Como funciona?

 Pide tu geoposicion para luego hacer un filtro de las sucursales mas cercanas a tu posicion y las pinta en el div a eleccion :),
 dudas o consultas claudio.figueroa.arias@gmail.com
*/
$(document).ready(function(){
 acordeon();
});
var marcadores_Sucursales = [

["Curico Plaza",-34.98599,-71.23914,"Estado 336 ","undefined","SI","SI","SI","Maule","Curico",1], 
["Universidad De Chile",-33.4428636,-70.6505178,"Ahumada 52 ","undefined","NO","NO","NO","Metropolitana","Santiago",2], 
["Bellas Artes",-33.4399001,-70.6454361,"Miraflores 222 ","undefined","NO","NO","NO","Metropolitana","Santiago",3], 
["Amunategui",-33.4401498,-70.6564053,"Huerfanos 1390 ","undefined","NO","NO","NO","Metropolitana","Santiago",4], 
["El Faro",-33.409306,-70.570216,"Av.apoquindo 5720 ","undefined","NO","NO","NO","Metropolitana","Las Condes",5], 
["Manuel Montt",-33.4293209,-70.6199626,"Manuel Montt 65 ","undefined","NO","NO","NO","Metropolitana","Providencia",6], 
["La Reina",-33.43896,-70.55825,"Av.principe De Gales 7121 ","undefined","NO","NO","NO","Metropolitana","La Reina",7], 
["Isidora Goyenechea",-33.4138375,-70.602788,"Isidora Goyenechea 2872 ","undefined","NO","NO","NO","Metropolitana","Las Condes",8], 
["Centro Empresas Iquique",-20.21318,-70.15226,"Luis Uribe 525 ","undefined","NO","NO","NO","Tarapaca","Iquique",9], 
["Osorno Bf",-40.573486,-73.134919,"Manuel a. Matta 610 ","undefined","NO","NO","NO","Los Lagos","Osorno",10], 
["Grandes Empresas",-33.41697,-70.59852,"Edificios Centrales","undefined","NO","NO","NO","Metropolitana","Santiago",11], 
["Banca Privada",-33.41459,-33.41459,"Av Andres Bello 2777 Piso 17","undefined","NO","NO","NO","Metropolitana","Las Condes",12], 
["Machali",-34.176022,-70.695376,"Avda. San Juan 133 L 12","undefined","NO","SI","NO","Libertador Gral. Bernardo Ohiggins","Machali",13], 
["Rancagua",-34.170051,-70.742176,"Sargento J.bernardo Cuevas 577 ","undefined","NO","NO","SI","Libertador Gral. Bernardo Ohiggins","Rancagua",14], 
["El Cobre",-34.187672,-70.719003,"C. El Cobre Pdte Frei 1330 L E-105 ","undefined","NO","NO","NO","Libertador Gral. Bernardo Ohiggins","Rancagua",15], 
["Rancagua Paseo",-34.169998,-70.742314,"Independencia 511 ","undefined","NO","SI","NO","Libertador Gral. Bernardo Ohiggins","Rancagua",16], 
["Select Rancagua",-34.17031,-70.74229,"Calle Campos 423 of 505 506 Y 507","undefined","NO","SI","NO","Libertador Gral. Bernardo Ohiggins","Rancagua",17], 
["Nucleo Empresas Rancagua",-34.57373,-70.98619,"Sargento J.bernardo Cuevas 577 ","undefined","NO","NO","NO","Libertador Gral. Bernardo Ohiggins","Rancagua",18], 
["Rancagua",-34.169828,-70.742050,"Calle Campos 376","undefined","NO","NO","NO","Libertador Gral. Bernardo Ohiggins","Rancagua",19], 
["Rancagua Bf",-34.169819,-70.743834,"Independencia 623 ","undefined","NO","NO","NO","Libertador Gral. Bernardo Ohiggins","Rancagua",20], 
["Rengo",-33.409641,-70.669263,"Av. Bisquertt 39 ","undefined","NO","SI","NO","Libertador Gral. Bernardo Ohiggins","Rengo",21], 
["San Vicente Tagua Tagua",-34.439846,-71.076275,"German Riesco 742 ","undefined","NO","SI","NO","Libertador Gral. Bernardo Ohiggins","San Vicente",22], 
["Curico",-34.983394,-71.241701,"Estado 356 ","undefined","NO","SI","NO","Maule","Curico",23], 
["Curico Mall",-34.990137,-71.244683,"Av Ohiggins 201 Loc. 43 ","undefined","NO","SI","NO","Maule","Curico",24], 
["Nucleo Empresas Curico",-34.98600,-71.23937,"Estado 356, 2° Piso","undefined","NO","NO","NO","Maule","Curico",25], 
["Curico Bf",-34.984903,-71.240201,"Merced 411","undefined","NO","NO","NO","Maule","Curico",26], 
["San Fernando Centro",-34.580617,-71.006789,"Av Manuel Rodriguez 765 ","undefined","NO","SI","NO","Libertador Gral. Bernardo Ohiggins","San Fernando",27], 
["San Fernando",-34.580608,-71.006779,"Manuel Rodriguez 983 ","undefined","NO","NO","NO","Libertador Gral. Bernardo Ohiggins","San Fernando",28], 
["Espacio Banefe San Fernando",-34.58744,-70.98711,"Av Manuel Rodriguez 765 ","undefined","NO","NO","NO","Libertador Gral. Bernardo Ohiggins","San Fernando",29], 
["Santa Cruz",-34.6402207,-71.367767,"Plaza De Armas 186 ","undefined","NO","SI","NO","Libertador Gral. Bernardo Ohiggins","Santa Cruz",30], 
["Talca Bf",-35.427627,-71.659512,"Uno Sur 1230 ","undefined","NO","NO","NO","Maule","Talca",31], 
["Cauquenes",-35.967587,-72.316934,"Victoria 401 ","undefined","NO","SI","NO","Maule","Cauquenes",32], 
["Constitucion",-35.331340,-72.411483,"Egaña 430","undefined","NO","SI","NO","Maule","Constitucion",33], 
["Linares Plaza",-35.846066,-71.598463,"Independencia 336 ","undefined","NO","NO","NO","Maule","Linares",34], 
["Linares",-35.846716,-71.594945,"Independencia 557 ","undefined","NO","SI","NO","Maule","Linares",35], 
["Espacio Banefe Linares",-35.84666,-71.59492,"Independencia 557 ","undefined","NO","NO","NO","Maule","Linares",36], 
["Parral",-36.139264,-71.829612,"Anibal Pinto 440 ","undefined","NO","SI","NO","Maule","Parral",37], 
["San Javier",-35.595752,-71.730001,"Arturo Prat 2302 ","undefined","NO","SI","NO","Maule","San Javier",38], 
["Talca Plaza",-35.4272478,-71.6646172,"Uno Sur 853 ","undefined","NO","SI","SI","Maule","Talca",39], 
["Campus U. De Talca",-35.42712,-71.66691,"Av. Lircay Sn ","undefined","NO","NO","NO","Maule","Talca",40], 
["Talca Centro",-35.427850,-71.659912,"5 Oriente 1085","undefined","NO","SI","SI","Maule","Talca",41], 
["Mall Del Maule",-35.432709,-71.630362,"Circunvalacion Oriente 1055 Loc B 04","undefined","NO","NO","NO","Maule","Talca",42], 
["Select Talca Catedral",-35.42712,-71.66691,"Uno Sur N° 690 Oficinas 915, 916, 917 Y 918, Edificio Plaza Talca","undefined","NO","SI","NO","Maule","Talca",43], 
["Nucleo Empresas Talca Plaza",-35.42710,-71.66468,"Uno Sur 853 ","undefined","NO","NO","NO","Maule","Talca",44], 
["Espacio Banefe Talca Plaza",-35.42710,-71.66468,"Uno Sur 853 ","undefined","NO","NO","NO","Maule","Talca",45], 
["Vicuña Mackenna",-33.4571695,-70.6313155,"Vicuna Mackenna 1230 ","undefined","NO","SI","NO","Metropolitana","Ñuñoa",46], 
["Seminario",-33.4522986,-70.6272017,"Av.irarrazaval 340 ","undefined","NO","SI","NO","Metropolitana","Ñuñoa",47], 
["10 De Julio",-33.4540074,-70.6494326,"Diez De Julio 1067 ","undefined","NO","SI","NO","Metropolitana","Santiago",48], 
["Endesa",-33.444412,-70.6457471,"Santa Rosa 76 ","undefined","NO","NO","NO","Metropolitana","Santiago",49], 
["Rauli",-33.4517822,-70.6360406,"Diez De Julio 357 ","undefined","NO","NO","NO","Metropolitana","Santiago",50], 
["Caja Aux. Uc Santa Lucia",-33.44137,-70.64175,"Lira 17 Piso 1 ","undefined","NO","NO","NO","Metropolitana","Santiago",51], 
["Avenida Matta",-33.459559,-70.647784,"Av.matta 1026 ","undefined","NO","SI","NO","Metropolitana","Santiago",52], 
["Santa Lucia",-33.4408296,-70.6413733,"Av.lib.bdo.ohiggins 408 ","undefined","NO","SI","NO","Metropolitana","Santiago",53], 
["Caja Aux. Uc - Hospital Clínico",-33.4403905,-70.6407188,"Av. Libertador Bernardo O´higgins 340","undefined","NO","NO","NO","Metropolitana","Santiago",54], 
["Portugal",-33.4428494,-70.6372879,"Diagonal Paraguay 265 ","undefined","NO","SI","NO","Metropolitana","Santiago",55], 
["Santa Rosa",-33.4426211,-70.6451444,"Av. Libertador Bernardo O´higgins 646","undefined","NO","NO","NO","Metropolitana","Santiago",56], 
["Espacio Banefe U. De Chile",-33.44283,-70.65060,"Ahumada 52 ","undefined","NO","NO","NO","Metropolitana","Santiago",57], 
["Bellavista",-33.4310735,-70.6271876,"Calle El Arzobispo 0655 ","undefined","NO","SI","NO","Metropolitana","Providencia",58], 
["Salvador",-33.4348022,-70.6278286,"Av. Providencia 455 Loc 101","undefined","NO","SI","NO","Metropolitana","Providencia",59], 
["Clinica Santa Maria",-33.4321191,-70.6290695,"Bellavista 0415","undefined","NO","NO","NO","Metropolitana","Providencia",60], 
["Miraflores",-33.4403846,-70.6455119,"Agustinas 604 ","undefined","NO","SI","NO","Metropolitana","Santiago",61], 
["Plaza Italia",-33.437372,-70.636760,"Irene Morales 10 ","undefined","NO","SI","NO","Metropolitana","Santiago",62], 
["Lido",-33.4390436,-70.6465975,"Huerfanos 679","undefined","NO","NO","NO","Metropolitana","Santiago",63], 
["Teatro Municipal",-33.4403352,-70.648191,"San Antonio 210","undefined","NO","NO","NO","Metropolitana","Santiago",64], 
["Moneda Centro Bf",-33.4418168,-70.6496668,"Moneda 938 ","undefined","NO","NO","NO","Metropolitana","Santiago",65], 
["Independencia",-33.4268868,-70.6544388,"Av. Independencia 390 ","undefined","NO","SI","NO","Metropolitana","Independencia",66], 
["Espacio Banefe Independencia",-33.42689,-70.65444,"Av. Independencia 390 ","undefined","NO","NO","NO","Metropolitana","Independencia",67], 
["Recoleta",-33.429977,-70.647124,"Av. Recoleta 279 ","undefined","NO","SI","NO","Metropolitana","Recoleta",68], 
["Patronato",-33.4300329,-70.6451561,"Santa Filomena 452 ","undefined","NO","NO","SI","Metropolitana","Recoleta",69], 
["Espacio Banefe Recoleta",-33.42991,-70.64703,"Recoleta N° 279","undefined","NO","NO","NO","Metropolitana","Recoleta",70], 
["Puente",-33.4352694,-70.652744,"Rosas 1088","undefined","NO","SI","NO","Metropolitana","Santiago",71], 
["21 De Mayo",-33.4342801,-70.6502087,"21 De Mayo 795 ","undefined","NO","NO","NO","Metropolitana","Santiago",72], 
["Plaza De Armas",-33.4380435,-70.651822,"Portal Bulnes 495 ","undefined","NO","SI","NO","Metropolitana","Santiago",73], 
["General Mackenna",-33.4331689,-70.6570548,"General Mackenna 1305 Loc 106 ","undefined","NO","NO","NO","Metropolitana","Santiago",74], 
["Principal",-33.4406891,-70.6496901,"Agustinas 920 ","undefined","NO","SI","SI","Metropolitana","Santiago",75], 
["Huerfanos",-33.4397016,-70.6519724,"Huerfanos 1081 ","undefined","NO","SI","NO","Metropolitana","Santiago",76], 
["Puente Bf",-33.4348482,-70.6515727,"Puente 721 ","undefined","NO","NO","NO","Metropolitana","Santiago",77], 
["Caja Aux.carrascal",-33.42671,-70.68182,"Carrascal 3390 ","undefined","NO","NO","NO","Metropolitana","Pudahuel",78], 
["Teatinos",-33.439984,-70.6547477,"Huerfanos 1269 ","undefined","NO","SI","SI","Metropolitana","Santiago",79], 
["Plaza Bulnes",-33.4449039,-70.6541351,"Av. B. Ohiggins 1296 ","undefined","NO","SI","NO","Metropolitana","Santiago",80], 
["Plaza Constitucion",-33.4411433,-70.6548664,"Agustinas 1295 ","undefined","NO","NO","NO","Metropolitana","Santiago",81], 
["Nataniel",-33.4456121,-70.6541289,"Nataniel Cox 35 ","undefined","NO","NO","NO","Metropolitana","Santiago",82], 
["Stgo Down Town",-33.4449857,-70.6562798,"Alameda 1449 Loc 6.","undefined","NO","SI","NO","Metropolitana","Santiago",83], 
["Agustinas",-33.4403584,-70.6520405,"Bandera 237","undefined","NO","SI","SI","Metropolitana","Santiago",84], 
["Espacio Banefe Teatinos",-33.43985,-70.65481,"Huerfanos 1269 ","undefined","NO","NO","NO","Metropolitana","Santiago",85], 
["Ahumada Bf",-33.4411928,-70.6521183,"Bandera 172","undefined","NO","NO","NO","Metropolitana","Santiago",86], 
["Ahumada Personas Iii",-33.4412844,-70.6513351,"Bombero Ossa 1040 ","undefined","NO","SI","SI","Metropolitana","Santiago",87], 
["Nueva Bandera",-33.441410,-70.651860,"Bandera 151","undefined","SI","SI","SI","Metropolitana","Santiago",88], 
["Casa Matriz",-33.441554,-70.6520603,"Bandera 140, Primer Piso                     ","undefined","NO","SI","NO","Metropolitana","Santiago",89], 
["Oficina Carrera",-33.441403,-70.651899,"Bombero Ossa 1068 ","undefined","SI","SI","SI","Metropolitana","Santiago",90], 
["La Bolsa",-33.4421841,-70.6505904,"Ahumada 86 ","undefined","NO","SI","NO","Metropolitana","Santiago",91], 
["Work Café Estado",-33.440966,-70.649314,"Estado 171","undefined","SI","SI","SI","Metropolitana","Santiago",92], 
["Espacio Banefe La Bolsa",-33.44218,-70.65067,"Ahumada 86 ","undefined","NO","NO","NO","Metropolitana","Santiago",93], 
["Centro",-33.4393815,-70.6487566,"Huerfanos 837 ","undefined","NO","NO","NO","Metropolitana","Santiago",94], 
["Matriz Pyme",-33.44159,-70.65236,"Bandera 140 Piso 1","undefined","NO","NO","NO","Metropolitana","Santiago",95], 
["Ñuble",-33.5407521,-71.2079137,"Av. Vic.mackenna 1347 ","undefined","NO","NO","NO","Metropolitana","Santiago",96], 
["Chicureo",-33.2780283,-70.6309784,"Av Chicureo S/n Centro Comercial Piedra Roja Loc 157","undefined","NO","SI","NO","Metropolitana","Colina",97], 
["Nueva Los Dominicos",-33.4010377,-70.5152247,"Av. Camino Del Alba 11969 Loc 311","undefined","NO","SI","NO","Metropolitana","Las Condes",98], 
["Las Condes",-33.4069189,-70.5609937,"Av. Las Condes 11090 ","undefined","NO","SI","NO","Metropolitana","Las Condes",99], 
["Mall Los Dominicos",-33.4014039,-70.5165464,"Camino El Alba 11865 Loc. 107 ","undefined","SI","SI","SI","Metropolitana","Las Condes",100], 
["Hospital Fach",-33.395023,-70.548444,"Avda Las Condes 8642","undefined","NO","NO","NO","Metropolitana","Las Condes",101], 
["Alto Las Condes",-33.3908732,-70.5462835,"Av.pdte.kennedy 9001 Loc.2088 ","undefined","NO","SI","NO","Metropolitana","Las Condes",102], 
["Francisco De Asis",-33.3729784,-70.5180519,"Av.las Condes 12287 Loc.23 Y 24 ","undefined","NO","SI","NO","Metropolitana","Las Condes",103], 
["Nueva Estoril",-33.3839478,-70.5338644,"Av.estoril 50 Loc 101 ","undefined","NO","SI","NO","Metropolitana","Las Condes",104], 
["Caja Aux. U. Del Desarrollo Las Condes",-33.392176,-70.501126,"Av Plaza 700 Interior Campus","undefined","NO","NO","NO","Metropolitana","Las Condes",105], 
["Caja Aux. U. De Los Andes",-33.4035608,-70.5086446,"San Carlos De Apoquindo 2200 ","undefined","NO","NO","NO","Metropolitana","Las Condes",106], 
["Cantagallo",-33.3734202,-70.5177857,"Av. Nueva Las Condes 12265 ","undefined","NO","NO","NO","Metropolitana","Las Condes",107], 
["Los Trapenses",-33.3443362,-70.5442931,"Caminio Los Trapenses 3515 Loc.208-209 ","undefined","NO","SI","NO","Metropolitana","Lo Barnechea",108], 
["El Rodeo",-33.3532258,-70.5216085,"El Rodeo 12642 ","undefined","NO","SI","NO","Metropolitana","Lo Barnechea",109], 
["Caja Aux. Los Bronces",-33.3633506,-70.5420648,"Av. Las Condes 11090, Vitacura (Suc. Las Condes)","undefined","NO","NO","NO","Metropolitana","Lo Barnechea",110], 
["La Dehesa",-33.3608432,-70.5149856,"Av. La Dehesa 1201 Loc. 106","undefined","NO","SI","NO","Metropolitana","Lo Barnechea",111], 
["Lo Curro",-33.3770108,-70.5687183,"Av. Santa Maria 6932 ","undefined","NO","SI","NO","Metropolitana","Vitacura",112], 
["Puerta Del Sol",-33.41239,-70.57863,"Puerta Del Sol 19 ","undefined","NO","SI","NO","Metropolitana","Las Condes",113], 
["Cerro El Plomo",-33.405679,-70.574275,"Cerro El Plomo 5630, Boulevard Nueva Las Condes 8","undefined","NO","SI","NO","Metropolitana","Las Condes",114], 
["La Gloria",-33.4115405,-70.5789559,"Av Apoquindo 4986 Al 4996 Loc 4 5 Y 6","undefined","NO","SI","NO","Metropolitana","Las Condes",115], 
["Parque Arauco",-33.4019547,-70.5796966,"Av.kennedy 5413 Loc.501 a ","undefined","NO","SI","NO","Metropolitana","Las Condes",116], 
["Apoquindo",-33.4066537,-70.5611947,"Av. Las Condes 6710 ","undefined","NO","SI","NO","Metropolitana","Las Condes",117], 
["El Faro Bf",-33.4088832,-70.5673674,"Av. Apoquindo 6091 ","undefined","NO","NO","NO","Metropolitana","Las Condes",118], 
["Los Cobres De Vitacura",-33.3889886,-70.568467,"Vitacura 6562 ","undefined","NO","SI","NO","Metropolitana","Vitacura",119], 
["Vitacura",-33.3991394,-70.5886997,"Av. Vitacura 4325 ","undefined","NO","SI","NO","Metropolitana","Vitacura",120], 
["Luis Pasteur",-33.3899534,-70.57914,"Luis Pasteur 5719 ","undefined","NO","NO","NO","Metropolitana","Vitacura",121], 
["Los Castaños",-33.388285,-70.566791,"Av.vitacura 6737 ","undefined","NO","NO","NO","Metropolitana","Vitacura",122], 
["Ciudad Empresarial",-33.388564,-70.619330,"Av. Sta. Clara 301 Loc.1804 ","undefined","NO","SI","SI","Metropolitana","Huechuraba",123], 
["Caja Aux. U. Mayor",-33.37729,-70.61677,"La Piramide 5750 Lote 7","undefined","NO","NO","NO","Metropolitana","Huechuraba",124], 
["El Golf",-33.416052,-70.592511,"Av. Apoquindo 3575 ","undefined","SI","SI","SI","Metropolitana","Las Condes",125], 
["Malaga",-33.415037,-70.586821,"Av. Apoquindo 4217 ","undefined","NO","SI","SI","Metropolitana","Las Condes",126], 
["Enrique Foster",-33.41592,-70.59393,"Apoquindo 3472 ","undefined","NO","SI","NO","Metropolitana","Las Condes",127], 
["El Regidor",-33.4164628,-70.5963751,"Av.apoquindo 3200 ","undefined","NO","SI","NO","Metropolitana","Las Condes",128], 
["World Trade Center",-33.41517,-70.60514,"Av. Andres Bello 2711 Loc.101 ","undefined","NO","SI","NO","Metropolitana","Las Condes",129], 
["Gertrudis Echenique",-33.4159065,-70.5917556,"G. Echenique 30 ","undefined","NO","SI","NO","Metropolitana","Las Condes",130], 
["El Bosque",-33.415213,-70.6011549,"Av. El Bosque Norte 0169 ","undefined","NO","SI","NO","Metropolitana","Las Condes",131], 
["Centro Empresas Santiago Oriente",-33.41603,-7.059388,"Av. Apoquindo 3472, Oficina 301","undefined","NO","NO","NO","Metropolitana","Las Condes",132], 
["Tobalaba",-33.4184259,-70.6019632,"Av. Providencia 2667 ","undefined","NO","SI","SI","Metropolitana","Providencia",133], 
["Encomenderos",-33.4184776,-70.6021822,"Av.providencia 2652 ","undefined","NO","NO","NO","Metropolitana","Providencia",134], 
["Costanera Center",-33.4177376,-70.607335,"Av Andres Bello 2465 Loc 113","undefined","NO","SI","NO","Metropolitana","Providencia",135], 
["Lo Castillo",-33.403278,-70.595150,"Av. Vitacura 3619 ","undefined","NO","SI","NO","Metropolitana","Vitacura",136], 
["Providencia",-33.421109,-70.6087059,"Av. Providencia 2259 ","undefined","NO","SI","SI","Metropolitana","Providencia",137], 
["Ricardo Lyon",-33.423127,-70.611746,"Paseo Orrego Luco 48 ","undefined","NO","NO","NO","Metropolitana","Providencia",138], 
["Pedro De Valdivia",-33.42582,-70.61405,"Av.11 De Septiembre 1877 Loc.1 ","undefined","NO","SI","SI","Metropolitana","Providencia",139], 
["Nueva Providencia",-33.4214158,-70.6079594,"Av. Nueva Providencia 2290","undefined","NO","SI","NO","Metropolitana","Providencia",140], 
["Antonio Varas",-33.4276788,-70.6176907,"Av.providencia 1414 ","undefined","NO","SI","NO","Metropolitana","Providencia",141], 
["Paseo Orrego Luco",-33.4230079,-70.6117052,"Av. Providencia 2047 ","undefined","NO","SI","SI","Metropolitana","Providencia",142], 
["Nueva Pedro De Valdivia",-33.423734,-70.612694,"Avenida Providencia # 2125","undefined","SI","SI","SI","Metropolitana","Providencia",143], 
["Caja Aux. Mantos Blancos",-33.42628,-7061164,"Av. Pedro De Valdivia 291 ","undefined","NO","NO","NO","Metropolitana","Providencia",144], 
["Drugstore",-33.4226196,-70.6111368,"Providencia 2124","undefined","NO","NO","NO","Metropolitana","Providencia",145], 
["Espacio Banefe Providencia",-33.42142,-70.60796,"Av. Nueva Providencia 2290","undefined","NO","NO","NO","Metropolitana","Providencia",146], 
["Principe De Gales",-33.439165,-70.559530,"Principe De Gales 7007 ","undefined","NO","SI","NO","Metropolitana","La Reina",147], 
["Irarrazaval",-33.4539576,-70.6053946,"Av. Irarrazaval 2458 ","undefined","NO","SI","SI","Metropolitana","Ñuñoa",148], 
["Plaza Egana",-33.4532708,-70.5738439,"Av. Irarrazaval 5380 ","undefined","NO","SI","NO","Metropolitana","Ñuñoa",149], 
["Ñuñoa",-33.4545017,-70.6030698,"Av.irarrazaval 2709 ","undefined","NO","SI","SI","Metropolitana","Ñuñoa",150], 
["Espacio Banefe Plaza Egana",-33.45319,-70.57389,"Av. Irarrazaval 5380 ","undefined","NO","NO","NO","Metropolitana","Ñuñoa",151], 
["Espacio Banefe Ñuñoa",-33.45454,-70.60303,"Av. Irarrázaval 2709","undefined","NO","NO","NO","Metropolitana","Ñuñoa",152], 
["Caja Aux. U. Adolfo Ibañez",-33.49013,-70.51898,"Diagonal Las Torres 2700 ","undefined","NO","NO","NO","Metropolitana","Peñalolen",153], 
["Pocuro",-33.43791,-70.60592,"Av. Fco De Bilbao 2082 ","undefined","NO","SI","NO","Metropolitana","Providencia",154], 
["Bilbao",-33.437862,-70.605574,"Av.fco.bilbao 2104 ","undefined","NO","NO","NO","Metropolitana","Providencia",155], 
["Hamburgo",-33.436621,-70.577578,"Av. Tobalaba N°5151, Local 203","undefined","NO","NO","NO","Metropolitana","Providencia",156], 
["Apumanque",-33.4091246,-70.5696713,"Av. Apoquindo 5810 ","undefined","NO","SI","SI","Metropolitana","Las Condes",157], 
["Avda. Larrain",-33.4532793,-70.5725611,"Av.irarrazaval 5560 ","undefined","NO","NO","NO","Metropolitana","Ñuñoa",158], 
["Buin",-33.7332364,-70.733737,"Bernardino Bravo #0115 Local N°1","undefined","NO","SI","NO","Metropolitana","Buin",159], 
["Altos De La Florida",-33.5421466,-70.5704139,"Av La Florida 9624","undefined","NO","SI","NO","Metropolitana","La Florida",160], 
["Peñaflor",-33.6099138,-70.9014409,"21 De Mayo 4580 a","undefined","NO","SI","NO","Metropolitana","Peñaflor",161], 
["Nueva Puente Alto",-33.6010248,-70.5776548,"Av Concha Y Toro 1050 ","undefined","NO","SI","NO","Metropolitana","Puente Alto",162], 
["Puente Alto",-33.6082862,-70.5764209,"Av.concha Y Toro 408 ","undefined","NO","SI","NO","Metropolitana","Puente Alto",163], 
["Plaza Tobalaba",-33.5742649,-70.5546305,"Av. Camilo Henriquez 3692 Loc 102 104 ","undefined","NO","SI","NO","Metropolitana","Puente Alto",164], 
["Punte Alto Bf",-33.60829,-70.57642,"Av.concha Y Toro 408 ","undefined","NO","NO","NO","Metropolitana","Puente Alto",165], 
["San Bernardo",-33.5946536,-70.7045904,"Covadonga 587 ","undefined","NO","SI","SI","Metropolitana","San Bernardo",166], 
["Eyzaguirre",-33.5797134,-70.7006946,"Av.eyzaguirre 598 ","undefined","NO","SI","NO","Metropolitana","San Bernardo",167], 
["San Bernardo Bf",-33.5955516,-70.706304,"Eyzaguirre 665 ","undefined","NO","NO","NO","Metropolitana","San Bernardo",168], 
["Talagante",-33.6635977,-70.9282467,"Av.bdo.ohiggins 994 ","undefined","NO","SI","SI","Metropolitana","Talagante",169], 
["Talagante Bf",-33.5020503,-70.7701976,"Ohiggins 810 ","undefined","NO","NO","NO","Metropolitana","Talagante",170], 
["Cerrillos",-33.4932092,-70.70721,"Las Americas 68 ","undefined","NO","SI","SI","Metropolitana","Cerrillos",171], 
["Plaza Oeste",-33.5173039,-70.7196237,"Av. Americo Vespucio 1501 Loc.114-116 ","undefined","NO","SI","NO","Metropolitana","Cerrillos",172], 
["Espacio Banefe Cerrillos",37.99477,-84.58732,"Las Americas 68 ","undefined","NO","NO","NO","Metropolitana","Cerrillos",173], 
["Espacio Banefe Plaza Oeste",-33.50331,-70.73848,"Av. Americo Vespucio 1501 Loc.114-116 ","undefined","NO","NO","NO","Metropolitana","Cerrillos",174], 
["La Cisterna",-33.5227513,-70.6600934,"Av. Jose M. Carrera 7070 ","undefined","NO","SI","NO","Metropolitana","La Cisterna",175], 
["Americo Vespucio",40.62876,-73.91827,"Av.j. M.carrera 8491 ","undefined","NO","SI","NO","Metropolitana","La Cisterna",176], 
["Americo Vespucio",-33.53301,-70.66341,"Gran Avenida 8491- Subterráneo ","undefined","NO","NO","NO","Metropolitana","La Cisterna",177], 
["Espacio Banefe La Cisterna",-33.52275,-70.66009,"Av. José M. Carrera 7070","undefined","NO","NO","NO","Metropolitana","La Cisterna",178], 
["Maipu",-33.4996358,-70.7576498,"Av. Pajaritos 3020 Loc.1 ","undefined","NO","SI","SI","Metropolitana","Maipu",179], 
["Ramon Freire",-33.5103189,-70.7779848,"Pajaritos 1640","undefined","NO","SI","SI","Metropolitana","Maipu",180], 
["5 De Abril Bf",-33.5108704,-70.7584423,"Av 5 De Abril 90. Loc.86 ","undefined","NO","NO","NO","Metropolitana","Maipu",181], 
["Espacio Banefe Maipu",-33.49971,-70.75767,"Av. Pajaritos 3020 Loc.1 ","undefined","NO","NO","NO","Metropolitana","Maipu",182], 
["Pedro Aguirre Cerda",-33.5012617,-70.7103349,"Av.p.aguirre Cerda 7003-a ","undefined","NO","SI","NO","Metropolitana","Pedro Aguirre Cerda",183], 
["Gran Avenida",-33.50024,-70.65371,"Av. Jose M. Carrera 5040 ","undefined","NO","SI","NO","Metropolitana","San Miguel",184], 
["San Miguel",-33.5018205,-70.6546118,"Av.j.m.carrera 5275 ","undefined","NO","SI","NO","Metropolitana","San Miguel",185], 
["San Nicolas",-33.4986411,-70.653708,"Avda. José Miguel Carrera 4919","undefined","NO","NO","NO","Metropolitana","San Miguel",186], 
["Espacio Banefe San Miguel",40.62850,-73.92522,"Av.j.m.carrera 5275 ","undefined","NO","NO","NO","Metropolitana","San Miguel",187], 
["Franklin",-33.4713467,-70.6485435,"San Diego 1925 ","undefined","NO","SI","NO","Metropolitana","Santiago",188], 
["San Diego",-33.4717405,-70.6485246,"San Diego 1983 ","undefined","NO","SI","NO","Metropolitana","Santiago",189], 
["Espacio Banefe San Diego",-33.47183,-70.64856,"San Diego 1983 ","undefined","NO","NO","NO","Metropolitana","Santiago",190], 
["Caja Aux. Las Tórtolas",-33.18807,-70.65770," Km 26 Carr.sn Martin Peldehue ","undefined","NO","NO","NO","Metropolitana","Colina",191], 
["El Cortijo",-33.366641,-70.697178,"Av Americo Vespucio 2880 Loc 1 ","undefined","NO","SI","SI","Metropolitana","Conchali",192], 
["Espacio Banefe El Cortijo",-33.38450,-70.75830,"Av Americo Vespucio 2880 Loc 1 ","undefined","NO","NO","NO","Metropolitana","Conchali",193], 
["Bascuñan Guerrero",-33.4506221,-70.6754615,"Bascunan Guerrero 30 ","undefined","NO","SI","NO","Metropolitana","Estacion Central",194], 
["Estacion Central",-33.4503327,-70.6773057,"Av..bdo.ohiggins 3177 ","undefined","NO","SI","SI","Metropolitana","Estacion Central",195], 
["Parque Estacion",-33.4533702,-70.6869943,"Av.bdo.ohiggins 3750 Loc.106 ","undefined","NO","SI","NO","Metropolitana","Estacion Central",196], 
["Caja Aux. Usach",-33.450743,-70.682754,"Enrique Kirberg N° 10","undefined","NO","NO","NO","Metropolitana","Estacion Central",197], 
["Espacio Banefe Estacion Central",-33.45033,-70.67731,"Av..bdo.ohiggins 3177 ","undefined","NO","NO","NO","Metropolitana","Estacion Central",198], 
["Mall Plaza Norte",-33.3662157,-70.6807182,"Av. Americo Vespucio 1737, Bp 116 ","undefined","NO","SI","NO","Metropolitana","Huechuraba",199], 
["Espacio Banefe Mall Plaza Norte",-33.36622,-70.67853,"Av. Americo Vespucio 1737, Bp 116 ","undefined","NO","NO","NO","Metropolitana","Huechuraba",200], 
["Enea",-33.4271203,-70.7804161,"Amercio Vespucio 1309 Loc.100 ","undefined","NO","SI","NO","Metropolitana","Pudahuel",201], 
["Caja Aux. Pudahuel",-33.404941,-70.791530,"Edif Terminal Carga Aerea Loc 2 Aeropue","undefined","NO","NO","NO","Metropolitana","Pudahuel",202], 
["Aeropuerto",-33.3833,-70.8333,"Aeropuerto a Merino Benitez Loc. .b 30 ","undefined","NO","SI","NO","Metropolitana","Pudahuel",203], 
["Quinta Normal",-33.4301805,-70.6919784,"Walker Martinez 1709 ","undefined","NO","SI","SI","Metropolitana","Quinta Normal",204], 
["Panamericana Norte",-33.4089248,-70.6803674,"Av Pdte E. Frei M. 1690 ","undefined","NO","SI","NO","Metropolitana","Renca",205], 
["Matucana",-33.43551,-70.6767505,"San Pablo 2976 ","undefined","NO","SI","NO","Metropolitana","Santiago",206], 
["San Pablo",-33.4352504,-70.6749071,"San Pablo 2810 ","undefined","NO","SI","NO","Metropolitana","Santiago",207], 
["Caja Aux. U. Diego Portales",-33.45018,-7065992,"Av Manuel Rodriguez 253","undefined","NO","NO","NO","Metropolitana","Santiago",208], 
["Republica",-33.4483763,-70.6691205,"Av. Bdo. O Higgins 2340 ","undefined","NO","SI","SI","Metropolitana","Santiago",209], 
["Espacio Banefe San Pablo",-33.43525,-70.67491,"San Pablo 2810","undefined","NO","NO","NO","Metropolitana","Santiago",210], 
["La Florida",-33.5217489,-70.5986985,"Av. Vic.mackenna 7430 ","undefined","NO","SI","NO","Metropolitana","La Florida",211], 
["Plaza Vespucio",-33.51868,-70.6017187,"Av.vic.mackenna 7110 Loc.e-1 ","undefined","NO","SI","NO","Metropolitana","La Florida",212], 
["Florida Center",-33.5099457,-70.6078913,"Av. Vic. Mackenna 6100 Loc 3114 ","undefined","NO","SI","NO","Metropolitana","La Florida",213], 
["Espacio Banefe La Florida",-33.52217,-70.59955,"Av. Vic.mackenna 7430 ","undefined","NO","NO","NO","Metropolitana","La Florida",214], 
["La Florida Bf",-33.51868,-70.6017187,"Av. Vic.mackenna 7110 Loc.11 ","undefined","NO","NO","NO","Metropolitana","La Florida",215], 
["Macul",-33.483639,-70.599052,"Av. Macul 3168 ","undefined","NO","SI","NO","Metropolitana","Macul",216], 
["Jose Pedro Alessandri",-33.4640902,-70.6070259,"Av.jose P.alessandri 2858 ","undefined","NO","SI","NO","Metropolitana","Macul",217], 
["Espacio Banefe Jose Pedro Alessandri",-33.47561,-70.59774,"Av.jose P.alessandri 2858 ","undefined","NO","NO","NO","Metropolitana","Macul",218], 
["Alto Penalolen",-33.4879397,-70.5491718,"Av. Consistorial 3349 Loc 5 Y 6 ","undefined","NO","SI","NO","Metropolitana","Peñalolen",220], 
["San Joaquin",-33.4812026,-70.6214188,"Vicuna Mackenna 3195 ","undefined","NO","SI","NO","Metropolitana","San Joaquin",221], 
["Rodrigo De Araya",-33.4794727,-70.6220743,"Av.vicuna Mackenna 3069 ","undefined","NO","SI","NO","Metropolitana","San Joaquin",222], 
["Campus San Joaquin",-33.4984845,-70.6178212,"Av.vic.mackenna 4860 Edif 400 ","undefined","NO","SI","NO","Metropolitana","San Joaquin",223], 
["Santa Elena",-33.47322,-70.62595,"Santa Elena 2236 ","undefined","NO","NO","NO","Metropolitana","San Joaquin",224], 
["Campus San Joaquin Ii",-33.499961,-70.6157637,"Av. Vicuña Mackenna 4927 C","undefined","NO","NO","NO","Metropolitana","San Joaquin",225], 
["Centro Empresas Santiago Sur",-33.48125,-70.62161,"Av. Vicuña Mackenna 3195","undefined","NO","NO","NO","Metropolitana","San Joaquin",226], 
["Concha Y Toro",-33.6162102,-70.5746357,"Av Concha Y Toro 311 ","undefined","NO","NO","NO","Metropolitana","Puente Alto",227], 
["Renca",-33.4072699,-70.680553,"Av. Pdte Edo. Frei M. 1780 ","undefined","NO","SI","NO","Metropolitana","Renca",228], 
["Arica Bolognesi",-18.477550,-70.319603,"21 De Mayo 204 ","undefined","NO","NO","SI","Arica y Parinacota","Arica",229], 
["Arica 21 De Mayo",-18.478572,-70.318612,"21 De Mayo 403 ","undefined","NO","SI","SI","Arica y Parinacota","Arica",230], 
["Espacio Banefe Arica 21 De Mayo",-18.47907,-70.31810,"21 De Mayo 403 ","undefined","NO","NO","NO","Arica y Parinacota","Arica",231], 
["Iquique 21 De Mayo",-20.213323,-70.151951,"Ignacio Serrano 343 ","undefined","NO","SI","SI","Tarapaca","Iquique",232], 
["Caja Aux. U. De Tarapaca",-18.487728,-70.294164,"Av 18 De Septiembre 2222","undefined","NO","NO","NO","Tarapaca","Iquique",233], 
["Iquique Plaza",-20.213361,-70.152222,"Luis Uribe 525 ","undefined","NO","NO","SI","Tarapaca","Iquique",234], 
["Iquique Zofri",-20.20540,-7014023,"Edificio De Convenciones Zofri Loc 2 ","undefined","NO","NO","NO","Tarapaca","Iquique",235], 
["Select Iquique",-20.21109,-70.15140,"Esmeralda 340 of 1203-1204","undefined","NO","SI","NO","Tarapaca","Iquique",236], 
["Iquique Plazuela Los Heroes",-20.216886,-70.139167,"Av Los Heroes De La Concepcion 2855 Loc 24","undefined","NO","NO","NO","Tarapaca","Iquique",237], 
["Iquique Bf",-20.213917,-70.150806,"Tarapaca 450 ","undefined","NO","NO","NO","Tarapaca","Iquique",238], 
["Antofagasta",-23.646986,-70.397700,"San Martin 2628 ","undefined","NO","SI","SI","Antofagasta","Antofagasta",239], 
["Antofagasta Av.brasil",-23.660438,-70.401329,"Av Ohiggins 1590 ","undefined","NO","SI","SI","Antofagasta","Antofagasta",240], 
["Select Antofagasta",-23.64666,-70.40042,"Av Jose Manuel Balmaceda 2472 of 112","undefined","NO","SI","NO","Antofagasta","Antofagasta",241], 
["Caja Aux. Uc Del Norte",-23.679149,-70.409840,"Angamos 0610 Edif J ","undefined","NO","NO","NO","Antofagasta","Antofagasta",242], 
["Antofagasta Plaza",-23.647130,-70.398020,"San Martin 2600 ","undefined","NO","SI","SI","Antofagasta","Antofagasta",243], 
["Antofagasta Infante",-23.555446,-70.391373,"Pedro Aguirre Cerda 11395, Local 1 Al 5","undefined","NO","SI","NO","Antofagasta","Antofagasta",244], 
["Caja Aux. Mejillones",-23.099626,-70.448212,"General Borgono 141 ","undefined","NO","NO","NO","Antofagasta","Antofagasta",245], 
["Antofagasta Mall",-23.642779,-70.397172,"Av. Balmaceda 2355 Loc.d ","undefined","NO","SI","NO","Antofagasta","Antofagasta",246], 
["Select Antofagasta Costanera",-23.64666,-70.40042,"Av. José M Balmaceda N° 2472 Oficina 142","undefined","NO","NO","NO","Antofagasta","Antofagasta",247], 
["Centro Empresas Antofagasta",-23.64697,-70.39761,"Av. San Martin 2634 Piso 5","undefined","NO","NO","NO","Antofagasta","Antofagasta",248], 
["Espacio Banefe Antofagasta",-23.64710,-7039778,"San Martin N° 2600","undefined","NO","NO","NO","Antofagasta","Antofagasta",249], 
["Espacio Banefe Antofagasta Infante",-23.57998,-70.39019,"Pedro Aguirre Cerda 9400 Loc 21 ","undefined","NO","NO","NO","Antofagasta","Antofagasta",250], 
["Espacio Banefe Antofagasta Mall",-23.64606,-70.40082,"Av. Balmaceda 2355 Loc.d ","undefined","NO","NO","NO","Antofagasta","Antofagasta",251], 
["Calama",-22.462613,-68.923721,"Sotomayor 1855 ","undefined","NO","SI","NO","Antofagasta","Calama",252], 
["Calama Mall",-23.641593,-70.396600,"Av. Balmaceda 3242 Loc Ed-100","undefined","NO","NO","NO","Antofagasta","Calama",253], 
["Calama Sotomayor",-22.462690,-68.926064,"Sotomayor 2026 ","undefined","NO","SI","SI","Antofagasta","Calama",254], 
["Select Calama",-22.45452,-68.92148,"Avenida Chorrillos N° 1631 Oficina 707 ","undefined","NO","SI","NO","Antofagasta","Calama",255], 
["Calama Bf",-22.462594,-68.924916,"Sotomayor 1928 ","undefined","NO","NO","NO","Antofagasta","Calama",256], 
["Copiapo",-27.366373,-70.333539,"Ohiggins 521 ","undefined","NO","SI","SI","Atacama","Copiapo",257], 
["Copiapo O'Higgins",-27.368168,-70.332784,"Colipi 320","undefined","NO","NO","SI","Atacama","Copiapo",258], 
["Copiapo Bf",-27.365315,-70.332015,"Chacabuco 545 ","undefined","NO","NO","NO","Atacama","Copiapo",259], 
["Coquimbo Aldunate",-29.951304,-71.337720,"Aldunate 822 ","undefined","NO","SI","SI","COQUIMBO","Coquimbo",260], 
["Coquimbo Benavente",-29.951087,-71.337743,"Aldunate 802 ","undefined","NO","NO","NO","COQUIMBO","Coquimbo",261], 
["Espacio Banefe Coquimbo",-29.95130,-71.33772,"Aldunate 822 ","undefined","NO","NO","NO","COQUIMBO","Coquimbo",262], 
["La Serena Balmaceda",-29.902020,-71.251052,"Balmaceda 351 ","undefined","NO","SI","SI","COQUIMBO","La Serena",263], 
["La Serena Plaza",-29.903310,-71.251922,"Cordovez 351 ","undefined","NO","SI","SI","COQUIMBO","La Serena",264], 
["La Serena Huanhuali",-29.913911,-71.256110,"Huanhuali 254 ","undefined","NO","NO","SI","COQUIMBO","La Serena",265], 
["Select La Serena",-29.90183,-71.25112,"Los Carreras 380 of 325-a","undefined","NO","SI","NO","COQUIMBO","La Serena",266], 
["La Serena Mall",-29.911769,-71.258493,"Alberto Solari 1400 Local 142 – 146 -b","undefined","NO","SI","NO","COQUIMBO","La Serena",267], 
["La Serena Cerro Grande",-29.945203,-71.241620,"Av. Cuatro Esquinas N° 1617 Local 112","undefined","NO","SI","SI","COQUIMBO","La Serena",268], 
["Select La Serena El Santo",-29.91081,-2991081,"Avda El Santo 1140 Oficina 5","undefined","NO","NO","NO","COQUIMBO","La Serena",269], 
["Espacio Banefe La Serena Plaza",-29.90333,-71.25192,"Cordovez 351 ","undefined","NO","NO","NO","COQUIMBO","La Serena",270], 
["Espacio Banefe La Serena Balmaceda",-29.90143,-71.24982,"Balmaceda 351 ","undefined","NO","NO","NO","COQUIMBO","La Serena",271], 
["Ovalle",-31.629774,-71.164799,"Victoria 322 ","undefined","NO","SI","SI","COQUIMBO","Ovalle",272], 
["Espacio Banefe Ovalle",-30.60409,-71.20316,"Victoria 322 ","undefined","NO","NO","NO","COQUIMBO","Ovalle",273], 
["Vallenar",-27.365759,-70.318695,"Arturo Prat 976 ","undefined","NO","SI","SI","Atacama","Vallenar",274], 
["Espacio Banefe Vallenar",-28.57640,-70.75948,"Arturo Prat N° 976","undefined","NO","NO","NO","Atacama","Vallenar",275], 
["Concepcion",-36.82918,-73.05345,"Bernardo Ohiggins 368 ","undefined","NO","SI","SI","BioBio","Concepcion",276], 
["El Trebol",-36.791027,-73.066986,"Autopista Talcahuano 8671 Loc 6 Y 7 B ","undefined","NO","SI","NO","BioBio","Concepcion",277], 
["Caja Aux. U. Del Desarrollo Concepción",-36.82174,-73.03694,"Ainavillo 451","undefined","NO","NO","NO","BioBio","Concepcion",278], 
["Caja Aux. U. San Sebastian",-36.81229,-73.04135,"Lientur 1325","undefined","NO","NO","NO","BioBio","Concepcion",279], 
["Select Concepcion Trinitarias",-36.82926,-73.04768,"Cochrane N°635, Piso 14, Oficina 1401 / Edificio Torre a","undefined","NO","SI","NO","BioBio","Concepcion",280], 
["Select Concepcion",-36.82824,-73.04274,"Chacabuco 1085 of 1201 P 12","undefined","NO","NO","NO","BioBio","Concepcion",281], 
["Concepcion Plaza",-36.826550,-73.050694,"Barros Arana 645 ","undefined","NO","NO","NO","BioBio","Concepcion",282], 
["Centro Empresas Concepcion",-36.82926,-73.04768,"Calle Cochrane N°635, Piso 12, Oficina 1201 / Edificio Torre a","undefined","NO","NO","NO","BioBio","Concepcion",283], 
["Espacio Banefe Concepción 11",-36.82924,-73.05333,"Bernardo Ohiggins 368 ","undefined","NO","NO","NO","BioBio","Concepcion",284], 
["Concepcion I",-36.827417,-73.052535,"Barros Arana 486 Loc 4 ","undefined","NO","NO","NO","BioBio","Concepcion",285], 
["San Pedro",-36.839526,-73.084604,"Av.pedro Aguirre Cerda 1055 ","undefined","NO","NO","NO","Metropolitana","San Pedro",286], 
["Talcahuano",-36.714353,-73.112024,"Colon 500 ","undefined","NO","SI","NO","BioBio","Talcahuano",287], 
["Caja Aux. Enap Talcahuano",-36.776238,-73.113789,"Camino a Lenga 2001 ","undefined","NO","NO","NO","BioBio","Talcahuano",288], 
["Talcahuano Colon",-36.743083,-73.097989,"Colon 3284 Loc B ","undefined","NO","NO","NO","BioBio","Talcahuano",289], 
["Base Naval",-36.725956,-73.105311,"Jorge Montt Sin Numero / Interior 22 Base Naval","undefined","NO","NO","NO","BioBio","Talcahuano",290], 
["Espacio Banefe Talcahuano",-36.71434,-73.11208,"Colon N° 500","undefined","NO","NO","NO","BioBio","Talcahuano",291], 
["Espacio Banefe El Trebol",-36.79169, -73.06936,"Autopista #8671 Loc. B6 Y B7","undefined","NO","NO","NO","BioBio","Talcahuano",292], 
["Concepcion Pedro De Valdivia",-36.848632,-73.050601,"Av.pedro De Valdivia 1303 ","undefined","NO","NO","NO","BioBio","Concepcion",293], 
["Plaza Peru",-36.829213,-73.045005,"Av. Chacabuco 891","undefined","NO","SI","NO","BioBio","Concepcion",294], 
["Concepcion Catedral",-36.828232,-73.051001,"Ohiggins 560 ","undefined","NO","SI","SI","BioBio","Concepcion",295], 
["Concepcion Chacabuco",-36.833117,-73.054320,"Chacabuco 149 ","undefined","NO","SI","NO","BioBio","Concepcion",296], 
["Select Nueva Concepcion",-36.78024, -73.05871,"Jorge Alessandri 3177 Piso 7","undefined","NO","NO","NO","BioBio","Concepcion",297], 
["Espacio Banefe Concepcion Catedral",-36.82823, -73.05100,"Ohiggins 560                           ","undefined","NO","NO","NO","BioBio","Concepcion",298], 
["Coronel",-37.021381,-73.154078,"Manuel Montt 301 Local B","undefined","NO","SI","NO","BioBio","Coronel",299], 
["Coronel Parque Industrial",-36.973214,-73.162142,"Av. Cordillera 3633 Oficina 2 ","undefined","NO","NO","NO","BioBio","Coronel",300], 
["Espacio Banefe Coronel",-36.82823,-73.05100,"Manuel Montt 301 Local B","undefined","NO","NO","NO","BioBio","Coronel",301], 
["San Pedro Del Valle",-36.838660,-73.119579,"Laguna Grande 115 Loc 32","undefined","NO","NO","NO","Metropolitana","San Pedro",302], 
["Chillan",-36.608958,-72.103451,"Arauco 726 ","undefined","NO","SI","SI","BioBio","Chillan",303], 
["Chillan Plaza",-36.607410,-72.102841,"Arauco 595 ","undefined","NO","SI","NO","BioBio","Chillan",304], 
["Espacio Banefe Chillan Plaza",-36.60739, -72.10283,"Arauco N° 595","undefined","NO","NO","NO","BioBio","Chillan",305], 
["Espacio Banefe Chillan",-36.60905, -72.10348,"Arauco N° 726","undefined","NO","NO","NO","BioBio","Chillan",306], 
["Laja",-37.262535,-72.724711,"Balmaceda 230 ","undefined","NO","NO","NO","BioBio","Laja",307], 
["Los Angeles",-37.470193,-72.349168,"Lautaro 281 ","undefined","NO","SI","NO","BioBio","Los Angeles",308], 
["Los Angeles Plaza",-37.470953,-72.350974,"Colon 257 ","undefined","NO","SI","SI","BioBio","Los Angeles",309], 
["Nucleo Empresa Los Angeles",-37.47019,-72.34917,"Lautaro 281 ","undefined","NO","NO","NO","BioBio","Los Angeles",310], 
["Espacio Banefe Los Angeles Plaza",-37.47019,-72.34917,"Colon 257 ","undefined","NO","NO","NO","BioBio","Los Angeles",311], 
["San Carlos",-36.425387,-71.958491,"Balmaceda 425 ","undefined","NO","SI","NO","BioBio","San Carlos",312], 
["Casablanca",-33.322076,-71.407881,"Av Portales 302","undefined","NO","SI","NO","Valparaiso","Casablanca",313], 
["Melipilla",-33.6837934,-71.2138181,"Av. Serrano 292 ","undefined","NO","SI","SI","Metropolitana","Melipilla",314], 
["Melipilla",-33.6838477,-71.2138217,"Ugalde 520 - Local a","undefined","NO","NO","NO","Metropolitana","Melipilla",315], 
["Espacio Banefe Melipilla",-33.68378, -71.21396,"Av. Serrano 292 ","undefined","NO","NO","NO","Metropolitana","Melipilla",316], 
["San Antonio Centro",-33.58074,-71.6121881,"Av. Centenario 81 ","undefined","NO","SI","NO","Valparaiso","San Antonio",317], 
["San Antonio",-33.593822,-71.613051,"Av.barros Luco 1613 Loc.3 ","undefined","NO","NO","SI","Valparaiso","San Antonio",318], 
["Espacio Banefe San Antonio",-33.58077, -71.61208,"Av. Centenario 81 ","undefined","NO","NO","NO","Valparaiso","San Antonio",319], 
["Valparaiso",-33.040640,-71.626363,"Prat 882 ","undefined","NO","SI","NO","Valparaiso","Valparaiso",320], 
["Congreso",-33.046377,-71.606999,"Chacabuco 2801 ","undefined","NO","SI","SI","Valparaiso","Valparaiso",321], 
["Valparaiso Esmeralda",-33.040798,-71.625894,"Esmeralda 939 ","undefined","NO","SI","SI","Valparaiso","Valparaiso",322], 
["Almendral",-33.045630,-71.607023,"Yungay 2802 ","undefined","NO","NO","NO","Valparaiso","Valparaiso",323], 
["Select Valparaiso",-32.78378,-71.19429,"Lord Cochranne 667 Piso 11","undefined","NO","SI","NO","Valparaiso","Valparaiso",324], 
["Caja Aux. U. De Valpo. Playa Ancha",-33.0257858,-71.6407195,"Av Enida Del Parque 627 Playa Ancha","undefined","NO","NO","NO","Valparaiso","Valparaiso",325], 
["Caja Aux. Emporchi",-33.03398, -71.62931,"Errazuriz 25 ","undefined","NO","NO","NO","Valparaiso","Valparaiso",326], 
["Placilla",-33.05251,-71.60179,"Ruta 68 1150 Loc 5 Placilla ","undefined","NO","SI","NO","Valparaiso","Valparaiso",327], 
["Centro Empresas Valparaiso",-33.04066, -71.62637,"Avenida Prat 882 Piso 2","undefined","NO","NO","NO","Valparaiso","Valparaiso",328], 
["Espacio Banefe Valparaiso Esmeralda",-33.04079 ,-71.62590,"Esmeralda 939 ","undefined","NO","NO","NO","Valparaiso","Valparaiso",329], 
["Caja Aux. U. Tec. Federico Santa Maria",-33.034434,-71.596766,"Av Espana 1680 ","undefined","NO","NO","NO","Valparaiso","Viña Del Mar",330], 
["Con-con",-32.927489,-71.498766,"Av Renaca Con Con Oo7","undefined","NO","SI","NO","Valparaiso","Con Con",331], 
["Reñaca",-32.970856,-71.539140,"Carlos Condell 115 Loc 3","undefined","NO","SI","NO","Valparaiso","Reñaca",332], 
["Viña Del Mar (Arlegui)",-33.02383,-71.55335,"Arlegui 618 ","undefined","NO","SI","SI","Valparaiso","Viña Del Mar",333], 
["Coraceros",-33.007937,-71.548627,"Benidorm 635 ","undefined","NO","SI","SI","Valparaiso","Viña Del Mar",334], 
["Viña Plaza",-33.031996,-71.567607,"Plaza Vergara 108 ","undefined","NO","NO","NO","Valparaiso","Viña Del Mar",335], 
["Viña Lider",-33.00681, -71.54524,"15 Norte 961 Loc. 1 ","undefined","NO","NO","NO","Valparaiso","Viña Del Mar",336], 
["Viña Libertad",-33.014362,-71.549976,"Av.libertad 781 ","undefined","SI","SI","SI","Valparaiso","Viña Del Mar",337], 
["Caja Aux. U. Adolfo Ibañez Viña Del Mar",-33.035205,-71.563209,"Padre Alberto Hurtado 750, Miraflores Alto Viña Del Mar","undefined","NO","NO","NO","Valparaiso","Viña Del Mar",338], 
["Select Vina Pacifico",-33.00808, -71.54851,"Libertad 1405 of 1503","undefined","NO","NO","NO","Valparaiso","Viña Del Mar",339], 
["Villanelo",-33.024200,-71.557250,"Av.valparaiso 383 ","undefined","NO","SI","NO","Valparaiso","Viña Del Mar",340], 
["Caja Aux. Las Salinas",-33.003797,-71.543675,"Subida Alessandri Sn Hospital Naval ","undefined","NO","NO","NO","Valparaiso","Viña Del Mar",341], 
["Centro Empresas Viña Del Mar",-33.00808, -71.54851,"Avenida Libertad N° 1405 Oficina 1901 Y 1902 ","undefined","NO","NO","NO","Valparaiso","Viña Del Mar",342], 
["Espacio Banefe Villanelo",-33.02419,-71.55725,"Av.valparaiso 383 ","undefined","NO","NO","NO","Valparaiso","Viña Del Mar",343], 
["Viña Del Mar Bf",-33.023126,-71.555380,"Etchevers 96 ","undefined","NO","NO","NO","Valparaiso","Viña Del Mar",344], 
["La Calera",-32.786847,-71.189815,"Jose Joaquin Perez 185 ","undefined","NO","SI","NO","Valparaiso","La Calera",345], 
["Espacio Banefe La Calera",-32.79115,-71.18308,"Jose Joaquin Perez 185 ","undefined","NO","NO","NO","Valparaiso","La Calera",346], 
["Limache",-32.985689,-71.275771,"Calle Serrano 251 ","undefined","NO","SI","NO","Valparaiso","Limache",347], 
["Caja Aux Terrapuerto Los Andes",-32.852366,-70.527109,"Ruta 57 Ch Km 79 Sector El Sauce","undefined","NO","NO","NO","Valparaiso","Los Andes",348], 
["Los Andes",-32.834198,-70.598336,"Ohiggins 348 ","undefined","NO","SI","NO","Valparaiso","Los Andes",349], 
["Espacion Banefe Los Andes",-32.83433, -70.59831,"Ohiggins 348 ","undefined","NO","NO","NO","Valparaiso","Los Andes",350], 
["Quillota",-32.87889,-71.24806,"San Martin 170 ","undefined","NO","SI","NO","Valparaiso","Quillota",351], 
["Quillota Plaza",-32.88061,-71.24733,"La Concepcion 345 ","undefined","NO","NO","NO","Valparaiso","Quillota",352], 
["La Ligua",-32.449018,-71.230639,"Ortiz De Rozas 485 ","undefined","NO","SI","NO","Valparaiso","Quillota",353], 
["Espacio Banefe Quillota",-32.87890, -71.24813,"San Martin 170 ","undefined","NO","NO","NO","Valparaiso","Quillota",354], 
["Quilpue",-33.046531,-71.444674,"Andres Bello 556 ","undefined","NO","SI","NO","Valparaiso","Quilpue",355], 
["Espacio Banefe Quilpue",-33.04655, -71.44464,"Andres Bello 556 ","undefined","NO","NO","NO","Valparaiso","Quilpue",356], 
["San Felipe",-32.7501766,-70.7239031,"Prat 942 ","undefined","NO","SI","NO","Valparaiso","San Felipe",357], 
["San Felipe Plaza",-32.7515436,-70.7254877,"Merced 850 ","undefined","NO","NO","NO","Valparaiso","San Felipe",358], 
["San Felipe Bf",-32.74992,-70.72576,"Prat 205 ","undefined","NO","NO","NO","Valparaiso","San Felipe",359], 
["Villa Alemana",-33.044292,-71.374084,"Av.valparaiso 755 ","undefined","NO","SI","NO","Valparaiso","Villa Alemana",360], 
["Espacio Banefe Villa Alemana",-33.04445, -71.37500,"Av. Valparaíso N° 755","undefined","NO","NO","NO","Valparaiso","Villa Alemana",361], 
["Rapa Nui",-27.14876,-109.43164,"Policarpo Toro Sn","undefined","NO","NO","NO","Valparaiso","Isla De Pascua",362], 
["Select Plaza El Golf",-33.41646, -70.59638,"Av Apoquindo 3200 Piso 4","undefined","NO","SI","NO","Metropolitana","Las Condes",363], 
["Select Alsacia",-33.41540, -70.59073,"Av Apoquindo 3846 of. 302 ","undefined","NO","SI","NO","Metropolitana","Las Condes",364], 
["Select Alcantara",-33.41511, -70.58935,"Apoquindo 3910 Piso 12","undefined","NO","SI","NO","Metropolitana","Las Condes",365], 
["Select Magdalena",-33.41480, -70.59372,"Magdalena 140 Piso 4 of 401 a","undefined","NO","SI","NO","Metropolitana","Las Condes",366], 
["Select Enrique Foster",-33.41603,-70.59388,"Av. Apoquindo 3472 of 201 Piso 2","undefined","NO","NO","NO","Metropolitana","Las Condes",367], 
["Select Augusto Leguia",-33.41646, -70.59638,"Av.apoquindo 3200 ","undefined","NO","SI","NO","Metropolitana","Las Condes",368], 
["Select Titanium",-33.41319, -70.60383,"Isidora Goyenechea 2800 of 4101 P 41","undefined","NO","SI","NO","Metropolitana","Las Condes",369], 
["Select El Bosque",-33.41811,-70.60051,"Avenida Apoquindo N° 2827, Oficina 1002","undefined","NO","SI","NO","Metropolitana","Las Condes",370], 
["Select Las Industrias",-33.41469, -70.60465,"Av Andres Bello 2777 Piso 18","undefined","NO","NO","NO","Metropolitana","Providencia",371], 
["Select Paseo Las Palmas",-33.42291,-70.60789,"Av Coyancura 2283 of 302","undefined","NO","SI","NO","Metropolitana","Providencia",372], 
["Select Marchant Pereira",-33.42621, -70.61313,"Marchant Pereira 150 of 301 P 3","undefined","NO","SI","NO","Metropolitana","Providencia",373], 
["Select Palladio",-33.42583,-70.61520,"Avda. Providencia 1770 Piso 6 of 604","undefined","NO","NO","NO","Metropolitana","Providencia",374], 
["Select Arrau",-33.40472, -70.57376,"Presidente Riesco 5561 of 203 P 2","undefined","NO","SI","NO","Metropolitana","Las Condes",375], 
["Select San Damian",-33.37683, -70.52738,"Av. Las Condes 11380 of 71 ","undefined","NO","SI","NO","Metropolitana","Las Condes",376], 
["Select Alonso De Cordova",-33.40761, -70.56901,"Alonso De Cordova 5900 of 1101 P 11","undefined","NO","SI","NO","Metropolitana","Las Condes",377], 
["Select Torre Apoquindo",-33.41268,-70.57979,"Apoquindo 4775 Piso 18","undefined","NO","NO","NO","Metropolitana","Las Condes",378], 
["Select Kennedy",-33.38457, -70.53288,"Av Estoril 200 of 626","undefined","NO","SI","NO","Metropolitana","Las Condes",379], 
["Select Mistral",-33.40424,-70.57260,"Rosario Norte 615 of 1804","undefined","NO","SI","NO","Metropolitana","Las Condes",380], 
["Select Edificio De Las Artes",-33.40523, -70.57381,"Cerro El Plomo #5680, Piso 4 of 402","undefined","NO","NO","NO","Metropolitana","Las Condes",381], 
["Select Lo Barnechea",-33.36084, -70.51499,"Av La Dehesa 1201 of 806","undefined","NO","SI","NO","Metropolitana","Lo Barnechea",382], 
["Select Vitacura Las Americas",-33.39699, -70.58391,"Av. Vitacura 5250 of 704","undefined","NO","SI","NO","Metropolitana","Vitacura",383], 
["Select Espoz",-33.39869, -70.58851,"Av Vitacura 4380 of 51","undefined","NO","NO","NO","Metropolitana","Vitacura",384], 
["Select Nueva Costanera",-33.39615, -70.59806,"Nueva Costanera 4040, Piso 2, Oficina 22 Edificio Live ","undefined","NO","SI","NO","Metropolitana","Vitacura",385], 
["Select Matias Cousino",-33.44076,-70.64989,"Matias Cousino 199 Piso 7","undefined","NO","NO","NO","Metropolitana","Santiago",386], 
["Select Torre Huerfanos",-33.43927, -70.64628,"Huerfanos 670, Piso 16 of. 1601","undefined","NO","SI","NO","Metropolitana","Santiago",387], 
["Select Torre Los Andes",-33.44110, -70.64554,"Miraflores 130 of 2301","undefined","NO","NO","NO","Metropolitana","Santiago",388], 
["Select Bandera",-33.44145, -70.65220,"Bandera 150 Piso 4","undefined","NO","SI","NO","Metropolitana","Santiago",389], 
["Select Eurocentro",33.44200, -70.65017,"Moneda 970 Piso 6 Loc 1","undefined","NO","NO","NO","Metropolitana","Santiago",390], 
["Select Moneda",33.44200, -70.65017,"Moneda 970 Piso 6 Loc 2","undefined","NO","SI","NO","Metropolitana","Santiago",391], 
["Select Estado",-33.44118, -70.64928,"Estado 152 Piso 7","undefined","NO","SI","NO","Metropolitana","Santiago",392], 
["Select Crillon",-33.44096, -70.65173,"Agustinas 1070 Piso 6 of 52","undefined","NO","SI","NO","Metropolitana","Santiago",393], 
["Select Opera",-33.43905, -70.64875,"Huerfanos 835 Piso 21","undefined","NO","SI","NO","Metropolitana","Santiago",394], 
["Select Nueva Agustinas",-33.44096, -70.65173,"Agustinas 1070 Piso 6 of 53","undefined","NO","NO","NO","Metropolitana","Santiago",395], 
["Select Santiago 2000",-33.43932, -70.64777,"Huerfanos 770 of 2003 P 20","undefined","NO","NO","NO","Metropolitana","Santiago",396], 
["Select Merced",-33.43794, -70.64429,"Merced 480 of 301","undefined","NO","NO","NO","Metropolitana","Santiago",397], 
["Select Morande",-33.43912,-70.65419,"Morande 360 Oficina N° 403 Piso 4","undefined","NO","NO","NO","Metropolitana","Santiago",398], 
["Select Matriz",-33.44145, -70.65220,"Bandera 150 Piso 3","undefined","NO","NO","NO","Metropolitana","Santiago",399], 
["Select Espacio M",-33.43912, -70.65419,"Morande 360, Oficina 401","undefined","NO","SI","NO","Metropolitana","Santiago",400], 
["Angol",-37.798465,-72.710016,"Lautaro 399 ","undefined","NO","SI","NO","Araucania","Angol",401], 
["Espacio Banefe Angol",-37.79855, -72.71054,"Lautaro 399 ","undefined","NO","NO","NO","Araucania","Angol",402], 
["Lautaro",-38.743635,-72.590194,"O Higgins 905 ","undefined","NO","SI","NO","Araucania","Lautaro",403], 
["Temuco",-38.740725,-72.591115,"A. Prat 724 Loc. 1 ","undefined","SI","SI","SI","Araucania","Temuco",404], 
["Victoria",-38.23329,-72.33195,"Eleuterio Ramírez 601","undefined","NO","SI","NO","Araucania","Temuco",405], 
["Temuco Plaza",-38.739342,-72.590727,"Arturo Prat 606 ","undefined","NO","NO","SI","Araucania","Temuco",406], 
["Temuco Ii",-38.733726,-72.614600,"Av Alemania 850","undefined","NO","NO","NO","Araucania","Temuco",407], 
["Select Temuco Recabarren",-38.74184, -72.59134,"Prat 847 of 706 Piso 7","undefined","NO","SI","NO","Araucania","Temuco",408], 
["Temuco Plaza Bbpp",-38.738968,-72.591398,"Claro Solar 757","undefined","NO","SI","NO","Araucania","Temuco",409], 
["Temuco Avenida Alemania",-38.733983,-72.613499,"Av. Alemania 0779 ","undefined","NO","SI","NO","Araucania","Temuco",410], 
["Select Temuco Capital",-38.74050, -72.58854,"Antonio Varas 989, Piso 19","undefined","NO","NO","NO","Araucania","Temuco",411], 
["Centro Empresas Temuco",-38.74184, -72.59134,"Arturo Prat N° 847 Piso 9 Oficina 901","undefined","NO","NO","NO","Araucania","Temuco",412], 
["Temuco Bulnes Bf",-38.73901,-72.58908,"Bulnes 563 ","undefined","NO","SI","NO","Araucania","Temuco",413], 
["Espacio Banefe Temuco Alemania",-38.73399,-72.61356,"Av. Alemania 0779 ","undefined","NO","NO","NO","Araucania","Temuco",414], 
["Traiguen",-38.249236,-72.668391,"Errazuriz 500 ","undefined","NO","SI","NO","Araucania","Traiguen",415], 
["La Union",-39.816805,-73.243148,"Esmeralda 603 ","undefined","NO","SI","NO","Los Ríos","La Union",416], 
["Panguipulli",-39.833466,-73.205676,"Martinez De Rosas 714 Loc 2","undefined","NO","SI","NO","Los Ríos","Panguipulli",417], 
["Pucon",-39.275722,-71.972800,"Av. Bdo.ohiggins 318 ","undefined","NO","SI","NO","Araucania","Pucon",418], 
["Rio Bueno",-40.296906,-73.082435,"Comercio 621 ","undefined","NO","NO","NO","Los Ríos","Rio Bueno",419], 
["Valdivia Arauco",-39.815077,-73.246882,"Arauco 149 ","undefined","NO","NO","SI","Los Ríos","Valdivia",420], 
["Valdivia",-39.814953,-73.246550,"Perez Rosales 585 ","undefined","NO","SI","NO","Los Ríos","Valdivia",421], 
["Universidad Austral Valdivia",-40.333948,-72.969919,"Av Carlos Ibanez De Campo Sn ","undefined","NO","SI","NO","Los Ríos","Valdivia",422], 
["Valdivia Bf",-39.813919,-73.246951,"Independencia 515 ","undefined","NO","NO","NO","Los Ríos","Valdivia",423], 
["Villarrica",-39.283282,-72.227316,"Av.pedro De Valdivia 778 ","undefined","NO","SI","NO","Araucania","Villarrica",424], 
["Villarrica Bf",-39.28303, -72.22755,"Pedro De Valdivia 748","undefined","NO","NO","NO","Araucania","Villarrica",425], 
["Frutillar",-41.133444,-73.027908,"Av.b.philippi 555 ","undefined","NO","NO","NO","Los Lagos","Frutillar",426], 
["Llanquihue",-41.257906,-73.004923,"V. Perez Rosales 322 ","undefined","NO","NO","NO","Los Lagos","Llanquihue",427], 
["Osorno",-40.5744802,-73.1366662,"Ohiggins 707 ","undefined","NO","SI","SI","Los Lagos","Osorno",428], 
["Osorno Plaza",-40.573353,-73.131547,"Eleuterio Ramirez 902 ","undefined","NO","NO","SI","Los Lagos","Osorno",429], 
["Nucleo Empresas Osorno Plaza",-40.57307, -73.13484,"Eleuterio Ramirez 902 ","undefined","NO","NO","NO","Los Lagos","Osorno",430], 
["Puerto Varas Casino",-41.31746,-72.98381,"San Jose 291 ","undefined","NO","NO","NO","Los Lagos","Puerto Varas",431], 
["Puerto Varas",-41.317956,-72.984789,"Del Salvador 399 ","undefined","NO","SI","NO","Los Lagos","Puerto Varas",432], 
["Purranque",-40.912235,-73.159282,"Pedro Montt 198 ","undefined","NO","NO","NO","Los Lagos","Purranque",433], 
["Puerto Montt",-41.471969,-72.942654,"Urmeneta 575 ","undefined","NO","NO","SI","Los Lagos","Puerto Montt",434], 
["Castro",-42.482975,-73.763709,"Blanco Encalada 324 ","undefined","NO","SI","NO","Los Lagos","Puerto Montt",435], 
["Puerto Montt Costanera",-41.472452,-72.941608,"Antonio Varas 501 ","undefined","NO","SI","SI","Los Lagos","Puerto Montt",436], 
["Puerto Montt P. Ibanez",-41.462045,-72.944402,"Av Presidente Ibanez 600 Loc.3 ","undefined","NO","NO","NO","Los Lagos","Puerto Montt",437], 
["Select Puerto Montt Costanera",-41.472993,-72.936729,"Juan Solar Manfredini 41 Piso 13","undefined","NO","SI","NO","Los Lagos","Puerto Montt",438], 
["Puerto Montt La Paloma",-41.460091,-72.922714,"Av. Volcán Puntiagudo N°100 Local 14","undefined","NO","NO","NO","Los Lagos","Puerto Montt",439], 
["Centro Empresas Puerto Montt",-41.47308,-72.93672,"Avenida Juan Soler Manfredini N°41, Piso 19","undefined","NO","NO","NO","Los Lagos","Puerto Montt",440], 
["Espacio Banefe Puerto Montt Constanera",-41.47254,-72.94163,"Antonio Varas 501 ","undefined","NO","NO","NO","Los Lagos","Puerto Montt",441], 
["Pto. Montt Bf",-41.472673,-72.943660,"Antonio Varas 636 ","undefined","NO","NO","NO","Los Lagos","Puerto Montt",442], 
["Coyhaique 21 De Mayo",-45.570408,-72.066620,"Condell 184 ","undefined","NO","SI","NO","Aysén","Coyhaique",443], 
["Espacio Banefe Coyhaique 21 De Mayo",-45.57047,-72.06631,"Condell 184 ","undefined","NO","NO","NO","Aysén","Coyhaique",444], 
["Puerto Aysen",-45.40624,-72.69898,"Av Arturo Prat 617","undefined","NO","SI","NO","Aysén","Puerto Aysen",445], 
["Puerto Natales",-51.727217,-72.503135,"Manuel Bulnes 598 ","undefined","NO","SI","NO","Magallanes","Puerto Natales",446], 
["Punta Arenas Plaza",-53.163365,-70.907733,"Plaza Munoz Gamero 1073 ","undefined","NO","SI","SI","Magallanes","Punta Arenas",447], 
["Punta Arenas",-53.161581,-70.905870,"Magallanes 997 ","undefined","NO","SI","SI","Magallanes","Punta Arenas",448], 
["Select Punta Arenas",-53.16366, -70.90756,"Presidente Roca 817 Piso 8","undefined","NO","SI","NO","Magallanes","Punta Arenas",449], 
["Nucleo Empresa Punta Arenas",-53.16337, -70.90772,"Plaza Munoz Gamero 1073 ","undefined","NO","NO","NO","Magallanes","Punta Arenas",450], 
["Espacio Banefe Punta Arenas Plaza",-53.16337, -70.90772,"Plaza Munoz Gamero 1073 ","undefined","NO","NO","NO","Magallanes","Punta Arenas",451], 
["Candelaria Goyenechea",-33.40171, -70.59342,"Av.vitacura 3783 ","undefined","SI","SI","SI","Metropolitana","Vitacura",452], 
["Escuela Militar",-33.41254, -70.58108,"Av. Apoquindo 4660","undefined","SI","SI","SI","Metropolitana","Las Condes",453] 


];

var map_Sucursales;
var infowindow;
var in_radio = [];     

 function initMap() {

       navigator.geolocation.getCurrentPosition(showPosition,showError);

  function showPosition(position){
 
            lat = position.coords.latitude;
            lon = position.coords.longitude;
            pyrmont = {lat: lat, lng: lon};
         

            map_Sucursales = new google.maps.Map(document.getElementById('mapholder'), {
              center: pyrmont,
              zoom: 18
            });
          // DONDE ESTAMOS //
            var marker = new google.maps.Marker({
              map: map_Sucursales,
              position: pyrmont
            });
          // FIN DONDE ESTAMOS //

            infowindow = new google.maps.InfoWindow();
           
            for(var i = 0; i < marcadores_Sucursales.length; i++){
                var myPosition = new google.maps.LatLng(lat,lon);
                var mark = new google.maps.LatLng(marcadores_Sucursales[i][1],marcadores_Sucursales[i][2]);
                var distance = google.maps.geometry.spherical.computeDistanceBetween(myPosition,mark);
                var radius = 100;
                    if(distance <= radius){
                        //createMarker(map_Sucursales[i]);
                        in_radio.push(marcadores_Sucursales[i]);
                        
                    }
            }

             for(var i = 0; i < marcadores_Sucursales.length; i++){ 

                  createMarker_all(marcadores_Sucursales[i]); 
             }

             for(var w = 0 ; w < in_radio.length; w++ ) { //Modo escritorio

              if(in_radio[w][5]=="NO"){
                   var comodin = '-';
                 }else{
                   var comodin = '<span class="icon-check2"></span>';
                 }

                 if(in_radio[w][6]=="NO"){
                   var comodin_2 = '-';
                 }else{
                   var  comodin_2 = '<span class="icon-check2"></span>';
                 }
                 if(in_radio[w][7]=="NO"){
                   var  comodin_3 = '-';
                 }else{
                   var  comodin_3 = '<span class="icon-check2"></span>';
                 }
                if(in_radio[w][4]=="undefined"){
                   var telefono = '-';
                 }else{
                  var telefono = in_radio[w][4];
                 }
              
               $('#repositorio_tr').append([
                    '<tr data-filtro="">',
                        '<td ><p class="tbody">'+in_radio[w]['0']+'</p></td>',
                        '<td ><p class="tbody">'+in_radio[w][3]+'</p></td>',
                        '<td class="filtros work_'+in_radio[w][5]+'" ><p class="tbody">'+comodin+'</p></td>',
                        '<td class="filtros impresion_'+in_radio[w][6]+'"><p class="tbody">'+comodin_2+'</p></td>',
                        '<td class="filtros cajero_'+in_radio[w][7]+'" ><p class="tbody">'+comodin_3+'</p></td>',
                        '<td class="accuracy"  data-lat="'+in_radio[w][1]+'" data-lon="'+in_radio[w][2]+'" ><p class="tbody mapa_over"> Ver mapa </p></td>',
                    '</tr>'
                    ].join(''));


                //Fin del recorrido 

                   //Mostraremos en el select en que region me encuentro 
                  $('.regiones_select').each(function(){
                        //in_radio[0][8] es la region del la primera posision del arreglo in_radio
                       var mi_region = $(this).val(in_radio[0][8]); //Traemos todos los value del select regiones
                  }); 
                   $('#regiones').attr('data-region',in_radio[0][8]);

                //Modo Responsive

                if(in_radio[w][5]=="NO"){
                   var cafe ='';
                 }else{;
                   var cafe = '<p class="table-content filtros work_'+in_radio[w][5]+'"><span class="icon-workcafe-taza"></span> WorkCafé</p>';
                 }
                 if(in_radio[w][6]=="NO"){
                   var impresion ='';
                 }else{
                   var impresion  = '<p class="table-content filtros impresion_'+in_radio[w][6]+'"><span class="icon-tarjeta"></span> Impresión de tarjetas</p>';
                 }
                 if(in_radio[w][7]=="NO"){
                   var cajero ='';
                 }else{
                   var cajero  = '<p class="table-content filtros cajero_'+in_radio[w][7]+'"><span class="icon-depositario"></span> Cajero automático para depósitos</p>';
                 }
                  if(in_radio[w][4]=="undefined"){
                   var telefono = '-';
                 }else{
                  var telefono = in_radio[w][4];
                 }


                 $('#repositorio_tr_mobile').append([
                  '<article data-filtro="">',
                      '<h4>'+in_radio[w][0]+'<span class="icon-flecha-abajo flecha"></span></h4>',
                        '<div class="block">',
                          '<div class="contenedorAcordeon">',
                              '<p class="table-content"><span class="icon-marker_map"></span>'+in_radio[w][3]+'</p>',
                              ''+cafe+'',
                              ''+impresion+'',
                              ''+cajero+'',
                              '<p class="table-content accuracy" data-lat="'+in_radio[w][1]+'" data-lon="'+in_radio[w][2]+'" ><a href="#" class="btn-mapa"><span class="icon-marker_map"></span> Ver mapa</a></p>',
                          '</div>',
                      '</div>',
                    '</article>',
                   ].join(''));
             
            }

            acordeon();
            in_region(in_radio[0][8]); //Pasamos el val de la region para completar el select de comunas

    }

     function showError(error){
        switch(error.code){
          case error.PERMISSION_DENIED:
            console.log("Denegada la peticion de Geolocalización en el navegador");
            reload_mapa(); //Hacemos el llamado de la funcion
            break;
          case error.POSITION_UNAVAILABLE:
             console.log("La información de la localización no esta disponible.");
            break;
          case error.TIMEOUT:
            console.log("El tiempo de petición ha expirado.");
            break;
          case error.UNKNOWN_ERROR:
            console.log("Ha ocurrido un error desconocido.");
            break;
          }
        } 

}   



function reload_mapa(){ //Si deniega el permiso automaticamente nos lleva a plaza de armas

     
        var lat= -33.4378439;
        var lon= -70.6504796;

        pyrmont = {lat: lat, lng: lon};
         

            map_Sucursales = new google.maps.Map(document.getElementById('mapholder'), {
              center: pyrmont,
              zoom: 18
            });
          // DONDE ESTAMOS //
            var marker = new google.maps.Marker({
              map: map_Sucursales,
              position: pyrmont
            });
          // FIN DONDE ESTAMOS //

            infowindow = new google.maps.InfoWindow();
           
            for(var i = 0; i < marcadores_Sucursales.length; i++){
                var myPosition = new google.maps.LatLng(lat,lon);
                var mark = new google.maps.LatLng(marcadores_Sucursales[i][1],marcadores_Sucursales[i][2]);
                var distance = google.maps.geometry.spherical.computeDistanceBetween(myPosition,mark);
                var radius = 400;
                    if(distance <= radius){
                        //createMarker(map_Sucursales[i]);
                        in_radio.push(marcadores_Sucursales[i]);
                        
                    }
            }

             for(var i = 0; i < marcadores_Sucursales.length; i++){ 

                  createMarker_all(marcadores_Sucursales[i]); 
             }

             for(var w = 0 ; w < in_radio.length; w++ ) { //Modo escritorio

              if(in_radio[w][5]=="NO"){
                   var comodin = '-';
                 }else{
                   var comodin = '<span class="icon-check2"></span>';
                 }

                 if(in_radio[w][6]=="NO"){
                   var comodin_2 = '-';
                 }else{
                   var  comodin_2 = '<span class="icon-check2"></span>';
                 }
                 if(in_radio[w][7]=="NO"){
                   var  comodin_3 = '-';
                 }else{
                   var  comodin_3 = '<span class="icon-check2"></span>';
                 }
                if(in_radio[w][4]=="undefined"){
                   var telefono = '-';
                 }else{
                  var telefono = in_radio[w][4];
                 }
              
               $('#repositorio_tr').append([
                    '<tr data-filtro="">',
                        '<td ><p class="tbody">'+in_radio[w]['0']+'</p></td>',
                        '<td ><p class="tbody">'+in_radio[w][3]+'</p></td>',
                        '<td class="filtros work_'+in_radio[w][5]+'" ><p class="tbody">'+comodin+'</p></td>',
                        '<td class="filtros impresion_'+in_radio[w][6]+'"><p class="tbody">'+comodin_2+'</p></td>',
                        '<td class="filtros cajero_'+in_radio[w][7]+'" ><p class="tbody">'+comodin_3+'</p></td>',
                        '<td class="accuracy"  data-lat="'+in_radio[w][1]+'" data-lon="'+in_radio[w][2]+'" ><p class="tbody mapa_over"> Ver mapa </p></td>',
                    '</tr>'
                    ].join(''));


                //Mostraremos en el select en que region me encuentro 
                  
                   $('#regiones').attr('data-region',in_radio[0][8]);

                //Modo Responsive

                if(in_radio[w][5]=="NO"){
                   var cafe ='';
                 }else{;
                   var cafe = '<p class="table-content filtros work_'+in_radio[w][5]+'"><span class="icon-workcafe-taza"></span> WorkCafé</p>';
                 }
                 if(in_radio[w][6]=="NO"){
                   var impresion ='';
                 }else{
                   var impresion  = '<p class="table-content filtros impresion_'+in_radio[w][6]+'"><span class="icon-tarjeta"></span> Impresión de tarjetas</p>';
                 }
                 if(in_radio[w][7]=="NO"){
                   var cajero ='';
                 }else{
                   var cajero  = '<p class="table-content filtros cajero_'+in_radio[w][7]+'"><span class="icon-depositario"></span> Cajero automático para depósitos</p>';
                 }
                  if(in_radio[w][4]=="undefined"){
                   var telefono = '-';
                 }else{
                  var telefono = in_radio[w][4];
                 }


                 $('#repositorio_tr_mobile').append([
                  '<article data-filtro="">',
                      '<h4>'+in_radio[w][0]+'<span class="icon-flecha-abajo flecha"></span></h4>',
                        '<div class="block">',
                          '<div class="contenedorAcordeon">',
                              '<p class="table-content"><span class="icon-marker_map"></span>'+in_radio[w][3]+'</p>',
                              ''+cafe+'',
                              ''+impresion+'',
                              ''+cajero+'',
                              '<p class="table-content accuracy" data-lat="'+in_radio[w][1]+'" data-lon="'+in_radio[w][2]+'" ><a href="#" class="btn-mapa"><span class="icon-marker_map"></span> Ver mapa</a></p>',
                          '</div>',
                      '</div>',
                    '</article>',
                   ].join(''));
             
            }
         
      acordeon(); //Activamos el acordeon
      in_region(in_radio[0][8]); //Pasamos el val de la region para completar el select de comunas
      $('#regiones').val(in_radio[0][8]);
}

 var marcador_sucursal;
 var datos_sucursal;
 var dato_direccion;
 var marketSpecial;
 var info_window;

 function newLocation(newLat,newLng){
  if (info_window) { info_window.close();} //Preguntamos si hay alguna market abierto si lo hay lo cerramos
    info_window = new google.maps.InfoWindow;
    for (var x=0;x < marcadores_Sucursales.length; x++){ //Recorremos los market 

        if(marcadores_Sucursales[x][1]==newLat && marcadores_Sucursales[x][2]==newLng){ //Preguntamos si langitud y la latitud son iguales a la seleccionada
           datos_sucursal = marcadores_Sucursales[x][0]; //Almacenos el Nombre 
           dato_direccion = marcadores_Sucursales[x][3]; //Almacenamos la direccion
           marketSpecial =  marcadores_Sucursales[x][5];

        }

    }
    var myLatlng = new google.maps.LatLng(newLat,newLng); //Nos movemos a la direccion del market seleccionado
    map_Sucursales.setCenter(myLatlng);

   info_window = new google.maps.InfoWindow({ //Abrimos el modal con el nombre
      content: datos_sucursal + "<br>"+  dato_direccion  //Carganos la data
    });

   if(marketSpecial == "SI"){ //Si es "si" cambiamos el market por uno de workface

   		marcador_sucursal = new google.maps.Marker({ //Creamos un market falso para darle el nombre
	      position: myLatlng,
	      map: map_Sucursales,
	      icon: 'img/pin-workcafe.png'
	    });

   }else{

	    marcador_sucursal = new google.maps.Marker({ //Creamos un market falso para darle el nombre
	      position: myLatlng,
	      map: map_Sucursales,
	      icon: 'img/pin-santander.png'
	    });
	}


    info_window.open(map_Sucursales,marcador_sucursal); //Abrimos el cartel con el nombre del market
     //map.setZoom(25);
      $('html,body').animate({ scrollTop: $("body").offset().top},'slow');
    
  }


$(document).delegate('.accuracy', 'click', function(){
      var lat = $(this).attr('data-lat');
      var lon = $(this).attr('data-lon');
      newLocation(lat,lon);
}); 

                        // FILTROS //

$(document).ready(function(){ 
   var click_filtros = 0;
   var suma_de_filtros; //1 tiene 2 no tiene

	    var misRegiones = [];
		var noRepetidos = [];

		for (var x = 0; x < marcadores_Sucursales.length; x ++){

			  misRegiones.push(marcadores_Sucursales[x][8]);
		}

		Array.prototype.unique=function(a){
		  return function(){return this.filter(a)}}(function(a,b,c){return c.indexOf(a,b+1)<0
		});

		var regionesNorepetidas = misRegiones.unique();

		regionesNorepetidas.forEach(function(item) {
			titulos_normal = item.toLowerCase();
			titulos_normal = toTitleCase(titulos_normal);
	    	$('#regiones').append('<option value="'+item+'">'+titulos_normal+'</option>');
		});

	    //Evento de click//

		$('#regiones').change(function(){ //Change o click al elemento region
		   var valor = $(this).val(); //Capturamos el valor para filtrar

		   if(valor == "Arica Y Parinacota"){
		   	   valor = "Arica";
		   }
	       $("#comunas").empty(); //Dejamos el select comuna vacio
	       noRepetidos.length=0; //Seteamos nuestro arreglo en 0

		   var arr = marcadores_Sucursales.filter(function(item){ //Filtramo
	       return item[8].toString().includes(valor);
	   	   });
		   for(var y = 0; y < arr.length; y++){ //Recorremos el array
		   	    noRepetidos.push(arr[y][9]); //Almacenamos en otro array para luego quitar los repetidos
		   }

		   var limpiar_array = noRepetidos.unique(); //Quitamos las repetidas
		   $('#comunas').append('<option value="">Seleccione comuna</option><option value="all">Todas</option>');
		   limpiar_array.forEach(function(item) { //Recorremos el array para insertarla en el select de comunas
	    	$('#comunas').append('<option value="'+item+'">'+item+'</option>');
		   });
		});

	  noRepetidos.length=0;

	  ordenarSelect('regiones'); //Ordenamos regiones	

      $('.regiones_select').change(function(){
         
       var select = $(this);
       var region = toTitleCase($(this).val());
       show_markets_region(region); //Pasamos la region a la funcion que esta mas abajo
       select.attr('data-region',region);
       ordenarSelect('comunas'); //Ordenamos las comunas por orden alfabetico
       volver_atras();
       $('html,body').animate({ scrollTop: $("#comunas").offset().top},'slow'); //Buscara el div en el body y bajaremos a el
       suma_de_filtros = 0;
       click_filtros = 0;
    });

    $('.comunas_select').change(function(){ // Pasamos la comuna a la funcion de mas abajo
   
      var comuna = $(this).val();
      comuna = comuna.replace("´","");
      show_markets_comunas(comuna);
      volver_atras();
      $('html,body').animate({ scrollTop: $("#comunas").offset().top},'slow'); //Buscara el div en el body y bajaremos a el
      suma_de_filtros = 0;
      click_filtros = 0;
   
    });

  $('.click_filtro_check').bind('change',function(){	
 
  $('.mensaje_error_map').html('');
    var btn = $(this);
    var data_td = $(this).attr('data-td');

    if(!$(btn).hasClass('activado_menu')){

        $(btn).addClass('activado_menu');
        $('.data-td.'+data_td).addClass('td_true');
        click_filtros= click_filtros +1;
    }else{

        $(btn).removeClass('activado_menu');
        $('.data-td.'+data_td).removeClass('td_true');
        click_filtros = click_filtros -1;
    }
     $('.data-td').each(function(){
        var btn = $(this);

         if($('.data-td').hasClass('td_true')){
            $('.data-td').hide();
            $('.data-td').filter('.td_true').show();                  
        }
     });
     $('#repositorio_tr td.filtros').removeClass('activado').addClass('hidden'); //A todos los td le quitamos en activado y luego los ocultamos ( version escritorio)
     $('#repositorio_tr_mobile p.filtros').removeClass('activado').addClass('hidden'); //A todas las p le quitamos el activado y lueego lo ocultamos (version responsive)

       $('.activado_menu').each(function(index,value) {
        var clase = $(this).attr('data-seleccionado'); //Capturamos lo que queremos filtrar de los checkbox
           $("#repositorio_tr td.filtros").each(function(){ //Recorremos todo los td del modo escritorio
               var div = $(this);  //Mismo div    
               if(div.hasClass(clase)){ //Preguntamos si en los td con clase filtro tiene lo que selecionaos
                 div.fadeIn('slow').removeClass('hidden');
                 div.addClass('activado'); 
                }
           });

           $("#repositorio_tr_mobile p.filtros").each(function(){ //Recorremos todo las p del modo responsive
               var div = $(this);      
               if(div.hasClass(clase)){
                 div.fadeIn('slow').removeClass('hidden');
                 div.addClass('activado');
                }
           });

       });
       if(!$('.click_filtro_check').hasClass('activado_menu')){ //Mostramos todo el contenido
        
         $('#repositorio_tr td.filtros').each(function(){
            $(this).fadeIn('slow').removeClass('hidden');
              
          });

         $('#repositorio_tr_mobile p.filtros').each(function(){
            $(this).fadeIn('slow').removeClass('hidden');
              
          });
         //$('.mensaje_error_map').empty(); //Borramos mensaje
        }
        $('#repositorio_tr tr').each(function(){ //Recorremos todo los tr
          var tr = $(this); //El mismo tr
          var td = tr.find('td.activado').length; //Contamos en cada tr cuantos td tiene la clase activado
          tr.attr('data-filtro',td);//Luego que tenemos la cantidad de activamos decada tr le damos el valor al data-filtro
           if(td==click_filtros){ 
             tr.show();
             suma_de_filtros = 1;
           }else{
            tr.hide();
            if(suma_de_filtros==1){
                  suma_de_filtros = 1;
            }else{
                suma_de_filtros = 2;
            }
    
     
           }
        });

        $('#repositorio_tr_mobile article').each(function(){ //Recorremos todos los articles
          var tr = $(this); //El mismo tr
          var td = tr.find('p.activado').length; //Luego que tenemos la cantidad de activamos decada tr le damos el valor al data-filtro
          tr.attr('data-filtro',td); //Psamos la cantidad de activado al mismo article ejemplo data-filtro = "+ cantidad"
           if(td==click_filtros){ 
             tr.show();
              suma_de_filtros = 1;
           }else{
            tr.hide();
	            if(suma_de_filtros==1){
	                  suma_de_filtros = 1;
	            }else{
	                suma_de_filtros = 2;
	            }
         	}
        });

       if(click_filtros==0){
         $('.data-td').show();
       }


      if(suma_de_filtros==2){
        $('.mensaje_error_map').html('No se encuentran resultados para la siguiente búsqueda.');      
      }

      suma_de_filtros =0;
     
    });
 $('#regiones').val(in_radio[0][8]);

}); 
    // FIN DE FILTROS //

function show_markets_region(region){ //Cargamos las regiones segun lo seleccionado en el select*
    var array_markets =[];
    var region = region.toLowerCase(); //Quitamos las mayusculas
    region = toTitleCase(region); //Inicial con mayuscula 
    $('.mensaje_error_map').empty(); //Borramos mensaje
    $('#repositorio_tr').empty();
    $('#repositorio_tr_mobile').empty();

    for(m=0; m<marcadores_Sucursales.length; m++){

      var all_regiones = marcadores_Sucursales[m][8].toLowerCase();
      all_regiones = toTitleCase(all_regiones);


      if(region==all_regiones){
          array_markets.push({"Sucursal":marcadores_Sucursales[m][0],"Direccion":marcadores_Sucursales[m][3],"Telefono":marcadores_Sucursales[m][4],"Workcafe":marcadores_Sucursales[m][5],"impresion_de_tarjetas":marcadores_Sucursales[m][6],"cajero_automatico":marcadores_Sucursales[m][7],"Latitud":marcadores_Sucursales[m][1],"Longitud":marcadores_Sucursales[m][2]});
      }
    }

   if(array_markets.length==0){

       $('.mensaje_error_map').html('No se encuentran sucursales para la región seleccionada.'); //Mensaje de error si no se encuetran sucursales
       $('.click_filtro_check').attr('disabled',true); //Desactivamos los checkbox

   }else{
      $('.click_filtro_check').attr('disabled',false); //Activamos los checkbox
     for(x=0;x<array_markets.length;x++){

        if(array_markets[x].Workcafe=="NO"){
           var comodin = '-';
        }else{
           var comodin = '<span class="icon-check2"></span>';
        }

        if(array_markets[x].impresion_de_tarjetas=="NO"){
            var comodin_2 = '-';
        }else{
            var comodin_2 = '<span class="icon-check2"></span>';
        }
        if(array_markets[x].cajero_automatico=="NO"){
            var  comodin_3 = '-';
        }else{
            var  comodin_3 = '<span class="icon-check2"></span>';
        }
        if(array_markets[x].Telefono=="undefined"){
          var telefono = "-";

        }else{
          var telefono = array_markets[x].Telefono;

        }
        $('#repositorio_tr').append([
            '<tr>',
              '<td ><p class="tbody">'+array_markets[x].Sucursal+'</p></td>',
              '<td ><p class="tbody">'+array_markets[x].Direccion+'</p></td>',
              '<td class="filtros work_'+array_markets[x].Workcafe+'"><p class="tbody">'+comodin+'</p></td>',
              '<td class="filtros impresion_'+array_markets[x].impresion_de_tarjetas+'"><p class="tbody">'+comodin_2+'</p></td>',
              '<td class="filtros cajero_'+array_markets[x].cajero_automatico+'"><p class="tbody">'+comodin_3+'</p></td>',
              '<td class="accuracy"  data-lat="'+array_markets[x].Latitud+'" data-lon="'+array_markets[x].Longitud+'" ><p class="tbody mapa_over">Ver mapa</p></td>',
            '</tr>'
        ].join(''));

        if(array_markets[x].Workcafe=="NO"){
            var cafe ='';
        }else{
            var cafe = '<p class="table-content filtros work_'+array_markets[x].Workcafe+'"><span class="icon-workcafe-taza"></span> WorkCafé</p>';
           
        }
        if(array_markets[x].impresion_de_tarjetas=="NO"){
            var impresion ='';
        }else{
            var impresion  = '<p class="table-content filtros impresion_'+array_markets[x].impresion_de_tarjetas+'"><span class="icon-tarjeta"></span> Impresión de tarjetas</p>';
             
        }
        if(array_markets[x].cajero_automatico=="NO"){
            var  cajero ='';
        }else{
            var cajero  = '<p class="table-content filtros cajero_'+array_markets[x].cajero_automatico+'"><span class="icon-depositario"></span> Cajero automático para depósitos</p>';
            
        }
        if(array_markets[x].Telefono=="undefined"){
          var telefono = "-";

        }else{
          var telefono = array_markets[x].Telefono;

        }


        $('#repositorio_tr_mobile').append([
                  '<article>',
                      '<h4>'+array_markets[x].Sucursal+'<span class="icon-flecha-abajo flecha"></span></h4>',
                        '<div class="block">',
                          '<div class="contenedorAcordeon">',
                              '<p class="table-content"><span class="icon-marker_map"></span>'+array_markets[x].Direccion+'</p>',
                               ''+cafe+'',
                                ''+impresion+'',
                                ''+cajero+'',
                                '<p class="table-content accuracy" data-lat="'+array_markets[x].Latitud+'" data-lon="'+array_markets[x].Longitud+'" ><a href="#" class="btn-mapa"><span class="icon-marker_map"></span> Ver mapa</a></p>',
                          '</div>',
                      '</div>',
                    '</article>',
        ].join(''));
      }
    }

    acordeon(); //Activamos el acordeon

}

function show_markets_comunas(comuna){ //Cargamos las comunas segun lo seleccionado en el select*
   var array_markets =[];
   $('#repositorio_tr').empty(); //Borramos para volver a dibujar las sucursales
   $('#repositorio_tr_mobile').empty();
   $('.mensaje_error_map').empty(); //Borramos mensaje
   var comparador = $('#regiones').attr('data-region');
    for(m=0; m<marcadores_Sucursales.length; m++){

      var all_comunas = marcadores_Sucursales[m][9]; //comunas
      var show_all = marcadores_Sucursales[m][8];  //La region

      if(comuna==all_comunas){

            array_markets.push({"Sucursal":marcadores_Sucursales[m][0],"Direccion":marcadores_Sucursales[m][3],"Telefono":marcadores_Sucursales[m][4],"Workcafe":marcadores_Sucursales[m][5],"impresion_de_tarjetas":marcadores_Sucursales[m][6],"cajero_automatico":marcadores_Sucursales[m][7],"Latitud":marcadores_Sucursales[m][1],"Longitud":marcadores_Sucursales[m][2]});

      }else if(comuna=="all"){ //Si selecciona todas

            if(comparador==show_all){ //Capturamos el data-region y lo comparamos con la posicion 8 de cada dato del array que es la region a la que corresponde
                  array_markets.push({"Sucursal":marcadores_Sucursales[m][0],"Direccion":marcadores_Sucursales[m][3],"Telefono":marcadores_Sucursales[m][4],"Workcafe":marcadores_Sucursales[m][5],"impresion_de_tarjetas":marcadores_Sucursales[m][6],"cajero_automatico":marcadores_Sucursales[m][7],"Latitud":marcadores_Sucursales[m][1],"Longitud":marcadores_Sucursales[m][2]});
            }
      }
    }

   if(array_markets==0){
      $('.mensaje_error_map').html('No se encuentran sucursales para la comuna seleccionada.');
       $('.click_filtro_check').attr('disabled',true); //Desactivamos los checkbox
   }else{
      $('.click_filtro_check').attr('disabled',false); //Activamos los checkbox
      for(x=0;x<array_markets.length;x++){

        if(array_markets[x].Workcafe=="NO"){
           var comodin = '-';
        }else{
           var comodin = '<span class="icon-check2"></span>';
        }

        if(array_markets[x].impresion_de_tarjetas=="NO"){
            var comodin_2 = '-';
        }else{
            var comodin_2 = '<span class="icon-check2"></span>';
        }
        if(array_markets[x].cajero_automatico=="NO"){
            var  comodin_3 = '-';
        }else{
            var  comodin_3 = '<span class="icon-check2"></span>';
        }
        if(array_markets[x].Telefono=="undefined"){
          var telefono = "-";

        }else{
          var telefono = array_markets[x].Telefono;

        }
        $('#repositorio_tr').append([
            '<tr>',
              '<td ><p class="tbody">'+array_markets[x].Sucursal+'</p></td>',
              '<td ><p class="tbody">'+array_markets[x].Direccion+'</p></td>',
              '<td class="filtros work_'+array_markets[x].Workcafe+'"><p class="tbody">'+comodin+'</p></td>',
              '<td class="filtros impresion_'+array_markets[x].impresion_de_tarjetas+'"><p class="tbody">'+comodin_2+'</p></td>',
              '<td class="filtros cajero_'+array_markets[x].cajero_automatico+'"><p class="tbody">'+comodin_3+'</p></td>',
              '<td class="accuracy"  data-lat="'+array_markets[x].Latitud+'" data-lon="'+array_markets[x].Longitud+'" ><p class="tbody mapa_over"> Ver mapa</p></td>',
            '</tr>'
        ].join(''));

        if(array_markets[x].Workcafe=="NO"){
             var cafe ='';
        }else{
           
            var cafe = '<p class="table-content filtros work_'+array_markets[x].Workcafe+'"><span class="icon-workcafe-taza"></span> WorkCafé</p>';
        }
        if(array_markets[x].impresion_de_tarjetas=="NO"){
             var impresion ='';
        }else{
             var impresion  = '<p class="table-content filtros impresion_'+array_markets[x].impresion_de_tarjetas+'"><span class="icon-tarjeta"></span> Impresión de tarjetas</p>';
            
        }
        if(array_markets[x].cajero_automatico=="NO"){
            var  cajero ='';
        }else{
             var cajero  = '<p class="table-content filtros cajero_'+array_markets[x].cajero_automatico+'"><span class="icon-depositario"></span> Cajero automático para depósitos</p>';
            
        }
         if(array_markets[x].Telefono=="undefined"){
          var telefono = "-";

        }else{
          var telefono = array_markets[x].Telefono;

        }

        $('#repositorio_tr_mobile').append([
                  '<article>',
                      '<h4>'+array_markets[x].Sucursal+'<span class="icon-flecha-abajo flecha"></span></h4>',
                        '<div class="block">',
                          '<div class="contenedorAcordeon">',
                              '<p class="table-content"><span class="icon-marker_map"></span>'+array_markets[x].Direccion+'</p>',
                               ''+cafe+'',
                                ''+impresion+'',
                                ''+cajero+'',
                                '<p class="table-content accuracy" data-lat="'+array_markets[x].Latitud+'" data-lon="'+array_markets[x].Longitud+'" ><a href="#" class="btn-mapa"><span class="icon-marker_map"></span> Ver mapa</a></p>',
                          '</div>',
                      '</div>',
                    '</article>',
        ].join(''));
      }
   }

    acordeon(); //Activamos el acordeon
}

function in_region(valor_region){ //Funcion para cargar las comunas una vez entra al sitio

	var noRepetidosComunas = [];

	var arr = marcadores_Sucursales.filter(function(item){ //Filtramos
	   return item[8].toString().includes(valor_region);
	});
		
	for(var y = 0; y < arr.length; y++){ //Recorremos el array

		 noRepetidosComunas.push(arr[y][9]); //Almacenamos en otro array para luego quitar los repetidos
	}

	var limpiar_array = noRepetidosComunas.unique(); //Quitamos las repetidas
	  $('#comunas').append('<option value="">Seleccione comuna</option><option value="all">Todas</option>');
	limpiar_array.forEach(function(item) { //Recorremos el array para insertarla en el select de comunas
		$('#comunas').append('<option value="'+item+'">'+item+'</option>');
	});
}


    // FUNCIONES ESPECIALES //

function acordeon(){ //Funciones acordion
        $('.block .contenedorAcordeon').hide();
        $('.accordion h4').click(function(){
            var is_active = false;
            if($(this).find("span.icon-flecha-abajo").hasClass('flechaActiva')){
                is_active = true;
            }
            $('.accordion h4 span.icon-flecha-abajo').removeClass("flechaActiva");
            if(!is_active){
                $(this).find("span.icon-flecha-abajo").addClass("flechaActiva");
            }
            if($(this).next().find('.contenedorAcordeon').is(':visible')){
                $(this).next().find('.contenedorAcordeon').slideUp();
            }
            if($(this).next().find('.contenedorAcordeon').is(':hidden')){
                $('.accordion h4').next().find('.contenedorAcordeon').slideUp();
                $(this).next().find('.contenedorAcordeon').slideDown();
            }
      });
}
function ordenarSelect(id_componente){ //Ordenar select comunas
      var selectToSort = $('#' + id_componente);
      var optionActual = selectToSort.val();
      selectToSort.html(selectToSort.children('option').sort(function (a, b) {
        return a.text === b.text ? 0 : a.text < b.text ? -1 : 1;
      })).val(optionActual);
}

function volver_atras(){
 $(function() {  
             $('.headList').each(function(){
                  $(this).removeClass('td_true');
                  $(this).show();
            });

            $('.click_filtro_check ').each(function(){
                  $(this).removeClass('activado_menu');
            });
		$('.click_filtro_check ').prop('checked', false);
      }); 

}

function createMarker_all(place){
	   
        // var placeLoc = place.geometry.location;
        if(place[5] == "SI"){

   		var marker = new google.maps.Marker({
	        map: map_Sucursales,
	        position: {lat:place[1],lng:place[2]},
	        title:place[0],
	        icon: 'img/pin-workcafe.png'
   		});

    	}else{

    	 var marker = new google.maps.Marker({
	        map: map_Sucursales,
	        position: {lat:place[1],lng:place[2]},
	        title:place[0],
	        icon: 'img/pin-santander.png'
   		});

    	}
}

function toTitleCase(str) {
    return str.replace(/(?:^|\s)\w/g, function(match) {
        return match.toUpperCase();
    });
}


Array.prototype.unique=function(a){
  return function(){return this.filter(a)}}(function(a,b,c){return c.indexOf(a,b+1)<0
});


 // FIN FUCIONES ESPECIALES //